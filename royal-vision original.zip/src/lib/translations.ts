/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SupportedLang = "fr" | "en" | "ar";

export interface TranslationSet {
  // Brand Header & Footer
  the_premiere: string;
  logo_subtitle: string;
  btn_reserve: string;
  btn_back_site: string;
  footer_desc: string;
  footer_all_rights: string;

  // Navigation Links
  nav_home: string;
  nav_about: string;
  nav_services: string;
  nav_packages: string;
  nav_gallery: string;
  nav_testimonials: string;
  nav_contact: string;

  // Hero Section
  hero_title: string;
  hero_subtitle: string;
  btn_discover_services: string;
  btn_book_pack: string;

  // About Section
  about_sub: string;
  about_title: string;
  about_text: string;
  highlight_excellence_title: string;
  highlight_excellence_desc: string;
  highlight_discretion_title: string;
  highlight_discretion_desc: string;
  highlight_noblesse_title: string;
  highlight_noblesse_desc: string;

  // Services Section
  services_sub: string;
  services_title: string;
  service_photo_title: string;
  service_photo_desc: string;
  service_video_title: string;
  service_video_desc: string;
  service_drone_title: string;
  service_drone_desc: string;

  // Packages Section
  packages_sub: string;
  packages_title: string;
  package_exclusive: string;
  package_recommended: string;
  btn_select_reserve: string;
  comparison_title: string;
  spec_header: string;
  spec_covers: string;
  spec_covers_bronze: string;
  spec_covers_silver: string;
  spec_covers_gold: string;
  spec_cinema: string;
  spec_cinema_bronze: string;
  spec_cinema_silver: string;
  spec_cinema_gold: string;
  spec_drone: string;
  spec_drone_bronze: string;
  spec_drone_silver: string;
  spec_drone_gold: string;
  spec_delivery: string;
  spec_delivery_bronze: string;
  spec_delivery_silver: string;
  spec_delivery_gold: string;
  spec_album: string;
  spec_album_bronze: string;
  spec_album_silver: string;
  spec_album_gold: string;

  // Gallery Section
  gallery_sub: string;
  gallery_title: string;
  gallery_filter_all: string;
  gallery_filter_photo: string;
  gallery_filter_video: string;
  gallery_empty: string;

  // Testimonials Section
  testimonials_sub: string;
  testimonials_title: string;
  testimonials_empty: string;

  // Contact / Reservation Section
  contact_sub: string;
  contact_title: string;
  contact_form_title: string;
  contact_studio: string;
  contact_whatsapp_desc: string;
  contact_follow: string;
  contact_zone: string;
  contact_zone_val: string;
  field_full_name: string;
  field_full_name_pl: string;
  field_whatsapp_phone: string;
  field_whatsapp_phone_pl: string;
  field_event_date: string;
  field_event_location: string;
  field_event_location_pl: string;
  field_package_desired: string;
  field_package_select: string;
  field_notes: string;
  field_notes_pl: string;
  btn_confirm_booking: string;
  booking_success_title: string;
  booking_success_desc: string;
  booking_ref: string;
  btn_new_booking: string;

  // Admin Section Login Gates
  admin_restricted: string;
  admin_sub: string;
  admin_email_label: string;
  admin_password_label: string;
  btn_login_email: string;
  btn_google_signin: string;
  label_or: string;
  admin_setup_instructions: string;
  admin_title: string;
  admin_logged_in_as: string;
  btn_logout: string;
  toast_saving: string;
  toast_saved: string;

  // Setup Admin auth custom helper
  admin_setup_title: string;
  admin_setup_desc: string;
  btn_create_admin_now: string;
  admin_setup_help: string;
  admin_setup_success: string;
  admin_setup_failed: string;
}

export const translations: Record<SupportedLang, TranslationSet> = {
  fr: {
    the_premiere: "Le Prestige",
    logo_subtitle: "L'art de la photo & cinéma",
    btn_reserve: "Réserver",
    btn_back_site: "Retour Site",
    footer_desc: "L'Art de la photo & cinématographie de mariage de prestige",
    footer_all_rights: "Tous droits réservés.",

    nav_home: "Accueil",
    nav_about: "À propos",
    nav_services: "Services",
    nav_packages: "Tarifs",
    nav_gallery: "Portfolio",
    nav_testimonials: "Témoignages",
    nav_contact: "Contact",

    hero_title: "L'Art de la Photo & Cadrage de Mariage",
    hero_subtitle: "Sublimez chacun de vos rituels d'amour par un regard cinématographique d'exception, d'élégance et de tradition séculaire.",
    btn_discover_services: "Découvrir nos services",
    btn_book_pack: "Réserver mon Pack",

    about_sub: "Qui Sommes-Nous ?",
    about_title: "Chaque Émotion Gravée Pour l'Éternité",
    about_text: "Depuis plus d'une décennie, Royal Vision orchestre et immortalise les noces les plus spectaculaires.\n\nNotre mission consiste à s'imprégner de l'atmosphère féerique de votre célébration pour en restituer toute la noblesse, à travers des portraits ciselés comme des bijoux, des prises de vue aériennes par drone majestueuses, et des films cinématographiques multi-caméras qui racontent l'authentique poésie de votre amour.\n\nDe la finesse du maquillage artistique capturé en macro gros plans, jusqu'aux panoramas spectaculaires de l'entrée majestueuse des mariés en tenues traditionnelles, nous scellons vos moments uniques avec un équipement de pointe et une sensibilité d'artisans d'art.",
    highlight_excellence_title: "Excellence d'Art",
    highlight_excellence_desc: "Chaque image est retouchée à la main comme un tableau de maître.",
    highlight_discretion_title: "Discrétion & Respect",
    highlight_discretion_desc: "Présence invisible et complice pour capter l'émotion naturelle.",
    highlight_noblesse_title: "Noblesse Tradition",
    highlight_noblesse_desc: "Mise en valeur royale des rituels et des parures ancestrales.",

    services_sub: "Savoir-Faire & Noblesse",
    services_title: "Nos Prestations d'Exception",
    service_photo_title: "Reportage Photo Haute Noblesse",
    service_photo_desc: "Prises de vue d'art illimitées, portraits de mariés royaux et instantanés d'émotions.",
    service_video_title: "Cinéma de Mariage Multicam 4K",
    service_video_desc: "Réalisation d'un véritable film cinématographique avec plans artistiques synchronisés.",
    service_drone_title: "Prises de Vues Drone Aériennes",
    service_drone_desc: "Perspectives majestueuses et panoramas saisissants de l'arrivée et du lieu des noces.",

    packages_sub: "Collections & Tarifs",
    packages_title: "Nos Formules Officielles",
    package_exclusive: "Formule exclusive",
    package_recommended: "Recommandé VIP",
    btn_select_reserve: "Sélectionner & Réserver",
    comparison_title: "Étude comparative des Collections",
    spec_header: "Prestations Clés",
    spec_covers: "Couverture Reportage",
    spec_covers_bronze: "Globale 1 Caméraman",
    spec_covers_silver: "Elite 1 Cadreur + Drone",
    spec_covers_gold: "Prestige Double Caméra",
    spec_cinema: "Best-Of Cinématique",
    spec_cinema_bronze: "Montage standard HD",
    spec_cinema_silver: "Highlight 7 min 4K",
    spec_cinema_gold: "Long métrage + Teaser 4K",
    spec_drone: "Prises Drone Aériennes",
    spec_drone_bronze: "Non inclus",
    spec_drone_silver: "Régulières de Jour",
    spec_drone_gold: "Drone Illimité Jour/Nuit",
    spec_delivery: "Supports de Restitution",
    spec_delivery_bronze: "Coffret Clé USB",
    spec_delivery_silver: "USB + Galerie Sécurisée",
    spec_delivery_gold: "Coffret Bois + USB + Drive",
    spec_album: "Album Photo d'Art",
    spec_album_bronze: "Luxe 100 Photos (13x18)",
    spec_album_silver: "Prestige 200 Photos (15x21)",
    spec_album_gold: "Majestueux XXL Encapsulé",

    gallery_sub: "Portfolio Clin d'Œil",
    gallery_title: "Instants Immortalisés",
    gallery_filter_all: "Tous",
    gallery_filter_photo: "Portraits & Photos",
    gallery_filter_video: "Cinématographie & Vidéo",
    gallery_empty: "Aucun chef-d'œuvre disponible dans ce dossier.",

    testimonials_sub: "Paroles de Mariés",
    testimonials_title: "Témoignages de leur Grand Jour",
    testimonials_empty: "Aucun témoignage n'a été publié pour le moment.",

    contact_sub: "Prendre Date & Co-créer",
    contact_title: "Discutons de Votre Jour J",
    contact_form_title: "Soumettre Votre Demande",
    contact_studio: "STUDIO DE CRÉATION",
    contact_whatsapp_desc: "WhatsApp Direct",
    contact_follow: "Abonnez-vous",
    contact_zone: "Zone d'Action",
    contact_zone_val: "Maroc, France, Chine & International",
    field_full_name: "Nom Complet",
    field_full_name_pl: "Ex: Yasmine Alaoui",
    field_whatsapp_phone: "Téléphone WhatsApp",
    field_whatsapp_phone_pl: "Ex: +212 6 12 34 56 78",
    field_event_date: "Date de l'Événement",
    field_event_location: "Lieu ou Ville de l'Événement",
    field_event_location_pl: "Ex: Kasbah Beldi, Marrakech",
    field_package_desired: "Formule ou Collection Souhaitée",
    field_package_select: "Sélectionner une formule ou pack...",
    field_notes: "Demandes Particulières / Vos Notes (Facultatif)",
    field_notes_pl: "Ex: Décrivez l'arrivée des mariés, rituels additionnels...",
    btn_confirm_booking: "Confirmer ma Demande & WhatsApp",
    booking_success_title: "Demande Envoyée avec Succès !",
    booking_success_desc: "Votre demande de réservation a bien été enregistrée par notre studio. Notre équipe va prendre contact avec vous sur WhatsApp pour finaliser les préparatifs.",
    booking_ref: "Référence",
    btn_new_booking: "Nouvelle réservation",

    admin_restricted: "ADMINISTRATION",
    admin_sub: "Accès réservé - Royal Vision",
    admin_email_label: "Adresse Email d'Administration",
    admin_password_label: "Mot de Passe",
    btn_login_email: "Se connecter par Email",
    btn_google_signin: "Google Sign-In",
    label_or: "OU",
    admin_setup_instructions: "Pour activer la connexion par email, assurez-vous d'activer le fournisseur d'accès 'Email/Password' sur votre console cloud Firebase ou utilisez le panneau d'installation rapide ci-dessous.",
    admin_title: "Tableau de Bord Royal Vision",
    admin_logged_in_as: "Connecté :",
    btn_logout: "Déconnexion",
    toast_saving: "Enregistrement...",
    toast_saved: "Enregistré avec succès !",

    admin_setup_title: "Créer / Mettre à Jour mon Compte Administrateur",
    admin_setup_desc: "Saisissez un mot de passe sécurisé pour initialiser ou réinitialiser le compte administrateur officiel",
    btn_create_admin_now: "Initialiser le Compte Administrateur",
    admin_setup_help: "Saisissez l'adresse email de l'administrateur et configurez son mot de passe de connexion.",
    admin_setup_success: "Compte administrateur créé et configuré avec succès ! Vous pouvez maintenant vous connecter.",
    admin_setup_failed: "Échec de l'initialisation du compte. Est-ce que Firebase Auth est activé ?"
  },
  en: {
    the_premiere: "The Prestige",
    logo_subtitle: "The Art of Wedding Photography & Cinema",
    btn_reserve: "Book Now",
    btn_back_site: "Exit Admin",
    footer_desc: "The Art of Prestige Wedding Photography & Cinematography",
    footer_all_rights: "All rights reserved.",

    nav_home: "Home",
    nav_about: "About Us",
    nav_services: "Services",
    nav_packages: "Rates",
    nav_gallery: "Portfolio",
    nav_testimonials: "Testimonials",
    nav_contact: "Contact",

    hero_title: "The Art of Wedding Photography & Cinema",
    hero_subtitle: "Sublime your sacred love bonds with an exceptional cinematic eye of absolute elegance and secular traditions.",
    btn_discover_services: "Discover Our Services",
    btn_book_pack: "Book My Pack",

    about_sub: "Who Are We?",
    about_title: "Recording Pure Emotions for Eternity",
    about_text: "For more than a decade, Royal Vision has orchestrated and immortalized the most spectacular weddings.\n\nOur mission is to soak in the magical atmosphere of your celebration to restore all its noble essence, through portraits sculpted like precious gems, majestic aerial drone views, and multicamera cinematic masterpieces that narrate the true story of your love.\n\nFrom the delicate wedding makeup details to the grandiose entry of the newlyweds in ancestral gowns, we seal your unique moments with elite gear and the deep touch of true artistic craftsmanship.",
    highlight_excellence_title: "Artistic Excellence",
    highlight_excellence_desc: "Every single image is carefully hand-retouched like a master painting.",
    highlight_discretion_title: "Discreet Presence",
    highlight_discretion_desc: "Invisible and friendly presence to capture authentic, natural movements.",
    highlight_noblesse_title: "Heritage Dignity",
    highlight_noblesse_desc: "A royal celebration highlighting beautiful traditional rituals and historic attire.",

    services_sub: "Savoir-Faire & Craftsmanship",
    services_title: "Our Elite Services",
    service_photo_title: "Noble Wedding Photojournalism",
    service_photo_desc: "Unlimited fine art shots, royal couple portraits, and authentic emotions frozen in time.",
    service_video_title: "4K Multi-Camera Cinema",
    service_video_desc: "Directing an authentic high-end film screenplay with synchronized artistic viewpoints.",
    service_drone_title: "Aerial Drone Cinematography",
    service_drone_desc: "Majestic bird's-eye views and stunning sweeping panoramas of your event entrance and venue.",

    packages_sub: "Collections & Pricing",
    packages_title: "Our Celebrated Packages",
    package_exclusive: "Exclusive Collection",
    package_recommended: "Recommended VIP Pack",
    btn_select_reserve: "Select & Secure Date",
    comparison_title: "Comparative Study of Collections",
    spec_header: "Key Deliverables",
    spec_covers: "Reportage Coverage",
    spec_covers_bronze: "Global 1 Cameraman",
    spec_covers_silver: "Elite 1 Operator + Drone",
    spec_covers_gold: "Prestige Dual Camera",
    spec_cinema: "Cinematic Highlight",
    spec_cinema_bronze: "Standard HD movie edit",
    spec_cinema_silver: "4K Cinematic Highlight (7m)",
    spec_cinema_gold: "Full Feature Film + 4K Teaser",
    spec_drone: "Aerial Drone Captures",
    spec_drone_bronze: "Not included",
    spec_drone_silver: "Regular Daytime Flights",
    spec_drone_gold: "Unlimited Day & Night Drone",
    spec_delivery: "Delivery Format",
    spec_delivery_bronze: "Signature USB Drive",
    spec_delivery_silver: "USB Drive + Safe Online Gallery",
    spec_delivery_gold: "Precious Wooden Box + USB + Drive",
    spec_album: "Artisan Photo Album",
    spec_album_bronze: "Luxe 100 Photo Album (13x18)",
    spec_album_silver: "Prestige 200 Photo Album (15x21)",
    spec_album_gold: "Majestuous XXL Hardcover",

    gallery_sub: "Portfolio Preview",
    gallery_title: "Immortallised Moments",
    gallery_filter_all: "All works",
    gallery_filter_photo: "Portraits & Photos",
    gallery_filter_video: "Cinema & Video Reels",
    gallery_empty: "No masterpieces available in this selection yet.",

    testimonials_sub: "Words of the Married",
    testimonials_title: "Testimonials from Their Big Day",
    testimonials_empty: "No testimonials have been published yet.",

    contact_sub: "Save Your Date",
    contact_title: "Let's Shape Your Wedding Film",
    contact_form_title: "Submit Your Booking Proposal",
    contact_studio: "DESIGN STUDIO",
    contact_whatsapp_desc: "Direct WhatsApp Line",
    contact_follow: "Follow Our Work",
    contact_zone: "Geographical Reach",
    contact_zone_val: "Morocco, France, China & Worldwide",
    field_full_name: "Full Name",
    field_full_name_pl: "e.g., Yasmine Alaoui",
    field_whatsapp_phone: "WhatsApp Number",
    field_whatsapp_phone_pl: "e.g., +212 6 12 34 56 78",
    field_event_date: "Event Date",
    field_event_location: "Event Location / City",
    field_event_location_pl: "e.g., Kasbah Beldi, Marrakech",
    field_package_desired: "Desired Collection Formula",
    field_package_select: "Select a package collection...",
    field_notes: "Special Requests / Extra Information (Optional)",
    field_notes_pl: "e.g., describe the entrance dress changes, custom rituals...",
    btn_confirm_booking: "Confirm Booking & Open WhatsApp",
    booking_success_title: "Proposal Submitted Successfully!",
    booking_success_desc: "Your booking order has been securely registered. Our creators will contact you directly on WhatsApp to coordinate your master film layout.",
    booking_ref: "Reference ID",
    btn_new_booking: "Make another booking",

    admin_restricted: "ADMINISTRATIVE LOGIN",
    admin_sub: "Authorized Personnel Only - Royal Vision",
    admin_email_label: "Admin Business Email",
    admin_password_label: "Admin Password",
    btn_login_email: "Sign In with Email",
    btn_google_signin: "Google Sign-In",
    label_or: "OR",
    admin_setup_instructions: "Enable 'Email/Password' authentication in your Firebase Console, or initialize/set your administrator password dynamically below.",
    admin_title: "Royal Vision Administrator Space",
    admin_logged_in_as: "Logged in as:",
    btn_logout: "Disconnect Session",
    toast_saving: "Saving...",
    toast_saved: "Changes saved successfully",

    admin_setup_title: "Initialize / Reset Admin Credentials",
    admin_setup_desc: "Directly assign or change the master password for the official administrator email below",
    btn_create_admin_now: "Create / Reset Admin User",
    admin_setup_help: "Enter the official admin accounts password to create the administrator account in your project database.",
    admin_setup_success: "Administrator user account configured successfully! You can now log in.",
    admin_setup_failed: "Setup failed. Check if Firebase Authentication is active in the console."
  },
  ar: {
    the_premiere: "الفخامة",
    logo_subtitle: "فن التصوير الفوتوغرافي والسينمائي",
    btn_reserve: "احجز الآن",
    btn_back_site: "العودة للموقع",
    footer_desc: "رويال فيجن - فن تصوير الأعراس الفاخرة والسينمائية المتميزة",
    footer_all_rights: "جميع الحقوق محفوظة.",

    nav_home: "الرئيسية",
    nav_about: "من نحن",
    nav_services: "خدماتنا",
    nav_packages: "الباقات",
    nav_gallery: "أعمالنا",
    nav_testimonials: "الآراء",
    nav_contact: "اتصل بنا",

    hero_title: "فن تصوير الأعراس والسينمائي الفاخر",
    hero_subtitle: "خلّدوا لحظاتكم ومراسم زفافكم بلمسة سينمائية بالغة الفخامة، تجسد الأناقة الخالدة والتقاليد العريقة للزفاف الملكي.",
    btn_discover_services: "اكتشف خدماتنا البارزة",
    btn_book_pack: "احجز الباقة المناسبة لي",

    about_sub: "من نحن ؟",
    about_title: "خلود المشاعر في لقطات تذكارية خالدة",
    about_text: "لأكثر من عقد من الزمان، تقوم رويال فيجن بتنظيم وتخليد أرقى حفلات الزفاف وأكثرها فخامة.\n\nتكمن مهمتنا في الانغماس التام في الأجواء الساحرة ليومكم الكبير، لننقل كل أبعاد نبل ومقام الحدث، عبر صور شخصية مشغولة بدقة متناهية كالجواهر الثمينة، ولقطات جوية Drone مهيبة، وأفلام سينمائية بكاميرات متعددة تروي جوهر وقصة حبكم الخالدة.\n\nمن تفاصيل الماكياج الفني الدقيق بلقطات ماكرو مكبرة، إلى المواكب الاستعراضية المهيبة لدخول العروسين الثنائي بالزي التقليدي؛ نختم لحظاتكم الاستثنائية بأحدث المعدات وشغف حِرَفي أصيل.",
    highlight_excellence_title: "التميز والبراعة الفنية",
    highlight_excellence_desc: "كل صورة يتم معالجتها يدوياً وتلوينها بدقة كلوحة فنية فريدة.",
    highlight_discretion_title: "حضور هادئ وحصيف",
    highlight_discretion_desc: "تواجد غير مرئي لمصورينا لتوثيق المشاعر الصادقة واللحظات الطبيعية تلقائياً.",
    highlight_noblesse_title: "إبراز الأصالة والتقاليد",
    highlight_noblesse_desc: "تسليط الضوء بمقام ملكي على الطقوس التقليدية والحلي والمجوهرات التراثية.",

    services_sub: "الخبرة والاتقان الأصيل",
    services_title: "خدماتنا الحصرية الراقية",
    service_photo_title: "توثيق فوتوغرافي رفيع المستوى",
    service_photo_desc: "تغطية كاملة ولقطات لا محدودة لملامح الفرحة وبورتريهات للزوجين بطابع ملكي فاخر.",
    service_video_title: "سينما زفاف احترافية متعددة الزوايا 4K",
    service_video_desc: "صناعة وإنتاج فيلم سينمائي متكامل يحاكي أعلى مستويات التحرير والمونتاج المتقن.",
    service_drone_title: "تصوير جوي Drone احترافي",
    service_drone_desc: "مشاهد بانورامية رائعة وزوايا طيران مهيبة توثق مدخل الحفل وفخامة مكان الزفاف.",

    packages_sub: "الباقات والعروض",
    packages_title: "عروضنا الحصرية المعتمدة",
    package_exclusive: "باقة حصرية",
    package_recommended: "موصى به لكبار الشخصيات VIP",
    btn_select_reserve: "اختر واحجز الآن",
    comparison_title: "مقارنة مواصفات الباقات الفاخرة",
    spec_header: "الخدمة والخصائص الأساسية",
    spec_covers: "طبيعة التغطية",
    spec_covers_bronze: "تغطية شاملة - مصور فيديو واحد",
    spec_covers_silver: "نخبة - مصور فيديو ومصور فوتوغرافي + تصوير جوي",
    spec_covers_gold: "بلاتينيوم - مصوران للفيديو ومصوران للصور الفوتوغرافية",
    spec_cinema: "المونتاج وملخص الفيديو",
    spec_cinema_bronze: "مونتاج فيلم كلاسيكي بصيغة HD",
    spec_cinema_silver: "ملخص سينمائي فاخر 4K (7 دقائق)",
    spec_cinema_gold: "فيلم طويل سينمائي متكامل + إعلان تشويقي 4K",
    spec_drone: "التصوير الجوي Drone",
    spec_drone_bronze: "غير مدرج",
    spec_drone_silver: "تصوير نهاراً خلال مراسم الزفاف",
    spec_drone_gold: "تصوير جوي مفتوح بلا حدود ليلاً ونهاراً",
    spec_delivery: "طريقة تسليم العمل",
    spec_delivery_bronze: "علبة فاخرة مع وحدة USB مخصصة",
    spec_delivery_silver: "وحدة USB + معرض الكتروني سحابي خاص بالعروسين",
    spec_delivery_gold: "صندوق خشبي مخصص + وحدة USB مخصصة + سحابة سياق الحماية والخصوصية",
    spec_album: "ألبوم صور فني فاخر",
    spec_album_bronze: "ألبوم ملكي يحتوي على 100 صورة مقاس (13x18)",
    spec_album_silver: "ألبوم النخبة المخصص يحتوي على 200 صورة مقاس (15x21)",
    spec_album_gold: "ألبوم بلاتينيوم XXL مغلف بالزجاج الفني الفاخر",

    gallery_sub: "معرض اللقطات والأعمال",
    gallery_title: "لحظات خالدة بجمالها الأصيل",
    gallery_filter_all: "الكل",
    gallery_filter_photo: "البورتريه والصور الفنية",
    gallery_filter_video: "السينما ومقاطع الفيديو",
    gallery_empty: "لا توجد أعمال لعرضها في هذا القسم حالياً.",

    testimonials_sub: "كلمات العروسين",
    testimonials_title: "آراء عملائنا الكرام وأزواجنا السعداء",
    testimonials_empty: "لم يتم نشر أي شهادات حتى الآن.",

    contact_sub: "تأكيد الموعد والتنسيق معاً",
    contact_title: "دعنا نناقش تفاصيل يوم زفافكم الكبير",
    contact_form_title: "أرسل طلب الحجز المبدئي",
    contact_studio: "استوديو رويال ديزاين",
    contact_whatsapp_desc: "واتساب مباشر للمستشار الإبداعي",
    contact_follow: "تابعوا جديد أعمالنا الفنية",
    contact_zone: "نطاق العمل والتواجد",
    contact_zone_val: "المملكة المغربية، فرنسا، الصين وكافة أنحاء العالم",
    field_full_name: "الاسم الكامل",
    field_full_name_pl: "مثال: ياسمين العلوي",
    field_whatsapp_phone: "رقم هاتف الواتساب ومفتاح البلد",
    field_whatsapp_phone_pl: "مثال: 78 56 34 12 6 212+",
    field_event_date: "تاريخ يوم الزفاف المخطط له",
    field_event_location: "مدينة أو مكان تنظيم الحفل",
    field_event_location_pl: "مثال: قصبة بيلدي، مراكش",
    field_package_desired: "الباقة الفنية المطلوبة",
    field_package_select: "الرجاء اختيار الباقة المناسبة للطلب...",
    field_notes: "طلبات خاصة أو تفاصيل إضافية (اختياري)",
    field_notes_pl: "مثال: تفاصيل تبديل الفساتين، طقوس وعادات خاصة ترغبون بتسليط الضوء عليها...",
    btn_confirm_booking: "تأكيد الطلب والتواصل الفوري عبر الواتساب",
    booking_success_title: "تم استلام وإرسال طلبكم بنجاح !",
    booking_success_desc: "تم تسجيل تفاصيل حجزكم المبدئي باهتمام كبير. سيقوم مستشارنا الفني بالتواصل معكم مباشرة عبر الواتساب لاستكمال تنسيق وإنتاج فيلم يومكم الكبير.",
    booking_ref: "رقم المرجع الثنائي للاستعلام",
    btn_new_booking: "إنشاء طلب حجز جديد",

    admin_restricted: "تسجيل دخول الإدارة",
    admin_sub: "قسم الإشراف حصرًا - رويال فيرست فيجن",
    admin_email_label: "البريد الإلكتروني المعتمد للإدارة",
    admin_password_label: "كلمة مرور الإدارة",
    btn_login_email: "سجل الآن باستخدام البريد الإلكتروني",
    btn_google_signin: "تسجيل الدخول باستخدام جوجل",
    label_or: "أو",
    admin_setup_instructions: "الرجاء تفعيل خيار الدخول بكلمة المرور في منصة فايربيس، أو قم بتعيين/إعادة تعيين كلمة مرور الإدارة الحماية والتوثيق من اللوحة أدناه مباشرة.",
    admin_title: "لوحة مشرفي رويال فيجن للتصوير الفاخر",
    admin_logged_in_as: "أنت متصل بصفتك :",
    btn_logout: "تسجيل الخروج المباشر",
    toast_saving: "جاري حفظ وتخزين التعديلات الحالية...",
    toast_saved: "تم حفظ التغييرات والبيانات بنجاح !",

    admin_setup_title: "تهيئة أو تحديث بيانات حساب الإدارة ومفتاح المرور",
    admin_setup_desc: "يمكنك إنشاء أو تعديل كلمة المرور المباشرة لبريدك الإلكتروني الإداري الرسمي من هنا مباشرة",
    btn_create_admin_now: "تهيئة حساب الإدارة وحماية الدخول",
    admin_setup_help: "أدخل كلمة مرور قوية ليتم تجهيز حساب الإدارة بالكامل وبدء استخدامه فوريًا.",
    admin_setup_success: "تم إعداد وعمل حساب المشرف والمسؤول بنجاح تام! يمكنك الآن تسجيل الدخول مباشرة بكفاءة عالية.",
    admin_setup_failed: "فشل إعداد الحساب. يرجى التحقق من اتصال قاعدة بيانات فايربيس للتصريح والتوثيق."
  }
};
