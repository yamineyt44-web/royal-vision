/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum BookingStatus {
  PENDING = "pending",
  CONFIRMED = "confirmed",
  CANCELLED = "cancelled"
}

export interface Booking {
  id: string; // Unique auto-generated booking number
  fullName: string;
  phone: string;
  eventDate: string;
  eventLocation: string;
  packageType: string;
  notes: string;
  status: BookingStatus;
  createdAt: string; // ISO String
}

export interface Package {
  id: string;
  name: string;
  price: string;
  features: string[]; // List of package features
  description: string;
  order: number;
}

export interface GalleryItem {
  id: string;
  url: string;
  type: "image" | "video";
  title: string;
  createdAt: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  role: string;
  text: string;
  rating: number; // 1 to 5
}

export interface WebsiteSettings {
  websiteName: string;
  logoText: string;
  heroTitle: string;
  heroSubtitle: string;
  aboutTitle: string;
  aboutText: string;
  contactWhatsApp: string; // WhatsApp number like +8615578369805 or full URL
  contactInstagram: string; // handle like royal.vision_
  primaryColor: string; // Hex code for gold e.g. #D4AF37
  darkBgColor: string; // Hex code for background e.g. #0A0A0C
  seoTitle: string;
  seoDescription: string;
}
