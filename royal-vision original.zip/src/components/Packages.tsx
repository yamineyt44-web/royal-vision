/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Check, ShieldCheck, Crown, Milestone, Layers } from "lucide-react";
import { Package } from "../types";
import { translations, SupportedLang } from "../lib/translations";

interface PackagesProps {
  packagesList: Package[];
  primaryColor: string;
  onSelectPackage: (packageName: string) => void;
  currentLang: SupportedLang;
}

export default function Packages({ packagesList, primaryColor, onSelectPackage, currentLang }: PackagesProps) {
  const t = translations[currentLang];

  // Preset comparisons metrics translated dynamically
  const comparisonSpecs = [
    {
      name: t.spec_covers,
      pack1: t.spec_covers_bronze,
      pack2: t.spec_covers_silver,
      pack3: t.spec_covers_gold,
    },
    {
      name: t.spec_cinema,
      pack1: t.spec_cinema_bronze,
      pack2: t.spec_cinema_silver,
      pack3: t.spec_cinema_gold,
    },
    {
      name: t.spec_drone,
      pack1: t.spec_drone_bronze,
      pack2: t.spec_drone_silver,
      pack3: t.spec_drone_gold,
    },
    {
      name: t.spec_delivery,
      pack1: t.spec_delivery_bronze,
      pack2: t.spec_delivery_silver,
      pack3: t.spec_delivery_gold,
    },
    {
      name: t.spec_album,
      pack1: t.spec_album_bronze,
      pack2: t.spec_album_silver,
      pack3: t.spec_album_gold,
    }
  ];

  // Map package data dynamically so that standard items appear as high-end localized content in English/Arabic
  const getLocalizedPackage = (pack: Package) => {
    if (currentLang === "fr") {
      const lowerFr = pack.name.toLowerCase();
      let frName = pack.name;
      if (lowerFr.includes("bronze") || lowerFr.includes("basic") || pack.id === "package_1") {
        frName = "Formule Basic: Wedding Film & Photography";
      } else if (lowerFr.includes("silver") || lowerFr.includes("premium") || pack.id === "package_2") {
        frName = "Formule Premium: Elite Cinema & Drone";
      } else if (lowerFr.includes("gold") || lowerFr.includes("royal") || pack.id === "package_3") {
        frName = "Formule Gold: Cinema Masterpiece";
      }
      return {
        ...pack,
        name: frName
      };
    }

    const lowerName = pack.name.toLowerCase();
    
    if (lowerName.includes("basic") || lowerName.includes("bronze")) {
      return {
        ...pack,
        name: currentLang === "ar" ? "الباقة الأساسية" : "Basic Package",
        description: currentLang === "ar" 
          ? "تغطية فوتوغرافية وسينمائية ممتازة ليوم زفافكم الفريد بجودة عالية."
          : "Essential high-end photography and cinematic coverage of your glorious day.",
        features: currentLang === "ar" ? [
          "تغطية كاملة من قِبل مصور محترف معتمد",
          "فيلم سينمائي كلاسيكي معدل بالكامل HD",
          "ألبوم صور فني فاخر يحتوي على 100 لقطة متميزة",
          "حقيبة تقديم أنيقة مخصصة لطلبكم"
        ] : [
          "Full day coverage by 1 certified elite camera operator",
          "Standard HD cinematically color-graded video edit",
          "Precious Luxe photo album housing 100 fine art pictures",
          "Personalized signature USB flash drive in custom box"
        ]
      };
    } else if (lowerName.includes("premium") || lowerName.includes("silver")) {
      return {
        ...pack,
        name: currentLang === "ar" ? "الباقة الفاخرة" : "Premium Package",
        description: currentLang === "ar"
          ? "الباقة الأكثر مبيعاً بالتصوير الجوي Drone وتغطية فريق ملكي متعدد الكاميرات."
          : "Our most popular selection containing elite Drone flights and double multicam operators.",
        features: currentLang === "ar" ? [
          "تغطية من قِبل مصور فوتوغرافي ومصور فيديو + طائرة Drone",
          "تغطية جوية Drone ساحرة لموقع ومحيط الحفل نهاراً",
          "ملخص رائع لفيلم الزفاف 4K بطول 7 دقائق للأهل والمنصات",
          "ألبوم صور النخبة الفاخر مع معرض صور رقمي سحابي آمن"
        ] : [
          "Full event coverage by 1 lead photographer + 1 videographer",
          "Exclusive raw Drone flights capturing venue beauty in daylight",
          "Fabulous 7-minute Cinematic Highlight 4K for direct preview",
          "Bespoke 200 photo print album + secured cloud web gallery"
        ]
      };
    } else {
      return {
        ...pack,
        name: currentLang === "ar" ? "الباقة الذهبية" : "Gold Package",
        description: currentLang === "ar"
          ? "قمة الفخامة بفيلم سينمائي طويل وتصوير جوي شامل وألواح تخزين حصرية."
          : "The ultimate luxury masterpiece experience including full-length cinema film and boundless drone captures.",
        features: currentLang === "ar" ? [
          "متابعة تامة وتغطية بكاميرتين سينمائيتين وطائرة درون مفتوحة",
          "تسليم الفيلم السينمائي الطويل المتكامل + إعلان تشويقي Teaser",
          "ألبوم صور XXL بلاتينيوم مغطى بالزجاج الفني الراقي",
          "صندوق خشبي حِرفي نادر مخصص لحفظ كافة مستندات وذكريات زفافكم"
        ] : [
          "Infinite day & night coverage by 2 cine-cameramen & drone flight",
          "Complete cinematic full-length motion picture + custom 4K teaser",
          "Majestic XXL prestige handcrafted acrylic hardcover glass album",
          "Hand-carved premium noble wood custom box containing all deliverables"
        ]
      };
    }
  };

  return (
    <section id="packages" className="py-28 bg-[#0A0A0A] border-b border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Package Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400 mb-3 block">
            {t.packages_sub}
          </p>
          <h3 className="font-serif text-3xl sm:text-4xl text-white font-semibold tracking-wide">
            {t.packages_title}
          </h3>
          <p className="text-stone-400 font-sans text-xs sm:text-sm mt-4 tracking-wide leading-relaxed">
            {currentLang === "fr" 
              ? "Sélectionnez la formule de vos rêves. Toutes nos options garantissent un travail artistique minutieux et un équipement de pointe."
              : currentLang === "ar"
              ? "تفخر رويال فيرست بتقديم باقات تصوير تلبي أدق متطلبات الأناقة. نضمن لكم جودة صور مذهلة وأحدث معدات الإنتاج."
              : "Select the collection format of your dreams. Every decision guarantees pristine editorial quality and vanguard media gear."
            }
          </p>
          <div className="w-16 h-[1.5px] mx-auto mt-6" style={{ backgroundColor: primaryColor }} />
        </div>

        {/* High-End Pricing Cards Display Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-24">
          {packagesList.map((pack) => {
            const localizedPack = getLocalizedPackage(pack);
            const isVip = pack.name.toLowerCase().includes("vip") || pack.name.toLowerCase().includes("gold") || pack.id === "package_3";
            const isPremium = pack.name.toLowerCase().includes("premium") || pack.name.toLowerCase().includes("silver") || pack.id === "package_2";

            return (
              <div
                key={pack.id}
                className={`relative flex flex-col justify-between border bg-[#0F0F0F] p-8 transition-all duration-500 hover:-translate-y-2 ${
                  isVip
                    ? "lg:scale-105 z-10"
                    : isPremium
                    ? "border-white/10 hover:border-[#C5A059]/45"
                    : "border-white/5 hover:border-[#C5A059]/25"
                }`}
                style={{
                  borderColor: isVip ? primaryColor : undefined,
                  boxShadow: isVip ? `0 10px 40px -10px ${primaryColor}10` : undefined,
                }}
              >
                {/* Floating Top Banner Tag */}
                {isVip && (
                  <div
                    className="absolute -top-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-4 py-1 text-[9px] font-mono uppercase tracking-[0.2em] text-black font-bold shadow-lg"
                    style={{ backgroundColor: primaryColor }}
                  >
                    <Crown className="w-3 h-3" /> {t.package_recommended}
                  </div>
                )}

                <div>
                  <span className="font-mono text-[9px] tracking-[0.25em] text-stone-400 uppercase block">
                    {t.package_exclusive}
                  </span>
                  
                  <h4 className="font-serif text-2xl text-white font-bold tracking-wide mt-2 mb-3">
                    {localizedPack.name}
                  </h4>
                  
                  <p className="text-stone-400 text-xs sm:text-sm tracking-wide leading-relaxed mb-6 font-light">
                    {localizedPack.description}
                  </p>



                  <ul className="space-y-4 mb-8">
                    {localizedPack.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-3">
                        <Check
                          className="w-4.5 h-4.5 mt-0.5 shrink-0"
                          style={{ color: primaryColor }}
                        />
                        <span className="text-stone-300 text-xs sm:text-sm leading-tight tracking-wide font-light">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => onSelectPackage(pack.name)}
                  className={`w-full py-4 text-[11px] uppercase tracking-[0.2em] font-semibold border transition-all duration-300 rounded-none cursor-pointer hover:bg-white hover:text-black hover:border-white`}
                  style={{
                    backgroundColor: isVip ? primaryColor : "transparent",
                    borderColor: primaryColor,
                    color: isVip ? "#000000" : primaryColor,
                  }}
                >
                  {t.btn_select_reserve}
                </button>
              </div>
            );
          })}
        </div>

        {/* Packages Comparison Matrix */}
        <div className="border border-white/5 bg-[#0F0F0F] p-4 sm:p-8 mt-12 overflow-x-auto">
          <div className={`flex items-center gap-3 mb-6 ${currentLang === "ar" ? "justify-start flex-row-reverse" : "justify-start"}`}>
            <Layers className="w-5 h-5 animate-pulse" style={{ color: primaryColor }} />
            <h4 className="font-serif text-white font-bold tracking-wider uppercase text-xs sm:text-sm">
              {t.comparison_title}
            </h4>
          </div>

          <table className={`w-full border-collapse min-w-[700px] ${currentLang === "ar" ? "text-right" : "text-left"}`}>
            <thead>
              <tr className="border-b border-white/5 pb-3 text-stone-400 font-mono text-[9px] uppercase tracking-[0.2em]">
                <th className={`py-3 pr-4 font-bold text-stone-200 ${currentLang === "ar" ? "text-right" : "text-left"}`}>{t.spec_header}</th>
                <th className={`py-3 font-bold text-stone-400 ${currentLang === "ar" ? "text-right" : "text-left"}`}>{currentLang === "ar" ? "الباقة الأساسية" : "Basic Package"}</th>
                <th className={`py-3 font-bold text-stone-300 ${currentLang === "ar" ? "text-right" : "text-left"}`}>{currentLang === "ar" ? "الباقة الفاخرة" : "Premium Package"}</th>
                <th className={`py-3 font-bold text-white ${currentLang === "ar" ? "text-right" : "text-left"}`}>{currentLang === "ar" ? "الباقة الذهبية" : "Gold Package"}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs sm:text-sm text-stone-300 tracking-wide font-light">
              {comparisonSpecs.map((spec, sIdx) => (
                <tr key={sIdx} className="hover:bg-white/5 transition-colors">
                  <td className="py-4 pr-4 font-medium text-stone-200">{spec.name}</td>
                  <td className="py-4 text-stone-400 leading-tight">{spec.pack1}</td>
                  <td className="py-4 text-stone-300 leading-tight font-medium" style={{ color: primaryColor }}>{spec.pack2}</td>
                  <td className="py-4 text-white leading-tight font-bold">{spec.pack3}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
