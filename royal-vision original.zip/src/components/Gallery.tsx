/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Play, Eye, Image as ImageIcon, Video as VideoIcon, AlignJustify, X } from "lucide-react";
import { GalleryItem } from "../types";
import { translations, SupportedLang } from "../lib/translations";

interface GalleryProps {
  galleryItems: GalleryItem[];
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function Gallery({ galleryItems, primaryColor, currentLang }: GalleryProps) {
  const [filter, setFilter] = useState<"all" | "image" | "video">("all");
  const [activeLightboxItem, setActiveLightboxItem] = useState<GalleryItem | null>(null);

  const t = translations[currentLang];

  const filteredItems = galleryItems.filter((item) => {
    if (filter === "all") return true;
    return item.type === filter;
  });

  return (
    <section id="gallery" className="py-28 bg-[#0a0a0a] border-b border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Gallery Title Block */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400 mb-3 block">
            {t.gallery_sub}
          </p>
          <h3 className="font-serif text-3xl sm:text-4xl text-white font-semibold tracking-wide">
            {t.gallery_title}
          </h3>
          <div className="w-16 h-[1.5px] mx-auto mt-6" style={{ backgroundColor: primaryColor }} />
        </div>

        {/* Media Category Filters */}
        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          {([
            { id: "all", label: t.gallery_filter_all, icon: AlignJustify },
            { id: "image", label: t.gallery_filter_photo, icon: ImageIcon },
            { id: "video", label: t.gallery_filter_video, icon: VideoIcon },
          ] as const).map((tab) => {
            const isActive = filter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id)}
                className={`flex items-center gap-2.5 px-6 py-3 uppercase text-[10px] tracking-[0.2em] font-bold cursor-pointer transition-all duration-300 ${
                  isActive
                    ? "text-black bg-white"
                    : "text-stone-400 border border-white/5 bg-[#0F0F0F] hover:text-white"
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Dynamic Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveLightboxItem(item)}
              className="group relative cursor-pointer aspect-[4/3] overflow-hidden border border-white/5 bg-[#0F0F0F] transition-transform duration-500 hover:-translate-y-1"
            >
              {/* Media Preview or Cover */}
              <img
                src={
                  item.type === "video"
                    ? "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=800"
                    : item.url
                }
                alt={item.title}
                className="w-full h-full object-cover filter brightness-[0.75] contrast-105 transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />

              {/* Hover Luxury Glass Shadow Overlay */}
              <div className="absolute inset-0 bg-black/85 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center p-6 text-center">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center border mb-4 text-white"
                  style={{ borderColor: primaryColor }}
                >
                  {item.type === "video" ? (
                    <Play className={`w-5 h-5 fill-current ${currentLang === "ar" ? "mr-0.5" : "ml-0.5"}`} style={{ color: primaryColor }} />
                  ) : (
                    <Eye className="w-5 h-5" style={{ color: primaryColor }} />
                  )}
                </div>
                
                <h5 className="font-serif text-white font-medium text-base tracking-wider mb-2 block">
                  {item.title}
                </h5>
                <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-stone-400 block">
                  {item.type === "video"
                    ? (currentLang === "ar" ? "فيديو سينمائي" : currentLang === "en" ? "Cinematic Video" : "Vidéo Cinématique")
                    : (currentLang === "ar" ? "تصوير فني" : currentLang === "en" ? "Fine Art Photography" : "Photographie d'art")
                  }
                </span>
              </div>

              {/* Dynamic tag indicators */}
              <div className={`absolute bottom-4 bg-black/90 border border-white/5 px-3 py-1.5 font-mono text-[8px] uppercase text-stone-300 tracking-widest flex items-center gap-1.5 pointer-events-none group-hover:opacity-0 transition-opacity ${currentLang === "ar" ? "right-4" : "left-4"}`}>
                {item.type === "video" ? (
                  <>
                    <VideoIcon className="w-3 h-3" style={{ color: primaryColor }} /> CINEMA
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-3 h-3" style={{ color: primaryColor }} /> PHOTO
                  </>
                )}
              </div>
            </div>
          ))}

          {filteredItems.length === 0 && (
            <div className="col-span-full py-16 text-center bg-[#0F0F0F] border border-white/5">
              <p className="text-stone-500 text-xs sm:text-sm tracking-widest uppercase font-mono block">
                {t.gallery_empty}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox Overlay Controller */}
      {activeLightboxItem && (
        <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-6" onClick={() => setActiveLightboxItem(null)}>
          <button
            onClick={() => setActiveLightboxItem(null)}
            className={`absolute top-6 p-3 bg-[#0F0F0F] border border-white/5 text-stone-400 hover:text-white transition-all cursor-pointer ${currentLang === "ar" ? "left-6" : "right-6"}`}
          >
            <X className="w-5 h-5" />
          </button>

          <div
            className="max-w-4xl w-full max-h-[85vh] relative flex flex-col items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            {activeLightboxItem.type === "video" ? (
              <div className="w-full aspect-video bg-neutral-900 relative">
                {/* Fallback elegant video player mock container containing details and play alerts */}
                <iframe
                  className="w-full h-full border-0 absolute inset-0"
                  src={
                    activeLightboxItem.url.includes("youtube.com") ||
                    activeLightboxItem.url.includes("youtu.be") ||
                    activeLightboxItem.url.includes("vimeo")
                      ? activeLightboxItem.url
                      : `https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1` // default placeholder fallback
                  }
                  title={activeLightboxItem.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            ) : (
              <img
                src={activeLightboxItem.url}
                alt={activeLightboxItem.title}
                className="max-w-full max-h-[70vh] object-contain border border-white/5 shadow-2xl"
                referrerPolicy="no-referrer"
              />
            )}

            <div className="text-center mt-6">
              <h4 className="font-serif text-white font-bold tracking-wide text-lg block">
                {activeLightboxItem.title}
              </h4>
              <p className="font-mono text-[9px] uppercase text-stone-400 tracking-[0.25em] mt-1 block">
                {activeLightboxItem.type === "video"
                  ? (currentLang === "ar" ? "إنتاج سينمائي احترافي" : currentLang === "en" ? "PROFESSIONAL CINEMATOGRAPHY" : "CINÉMATOGRAPHIE PROFESSIONNELLE")
                  : (currentLang === "ar" ? "بورتريه فني حصري" : currentLang === "en" ? "EXCLUSIVE FINE ART PORTRAIT" : "PORTRAIT EXCLUSIF D'ART")
                }
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
