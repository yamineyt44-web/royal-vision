/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  signInWithEmailAndPassword,
  signOut,
  User,
  GoogleAuthProvider,
  signInWithPopup,
  createUserWithEmailAndPassword,
  updatePassword,
} from "firebase/auth";
import {
  collection,
  getDocs,
  setDoc,
  doc,
  deleteDoc,
  updateDoc,
} from "firebase/firestore";
import {
  Lock,
  LogOut,
  Sliders,
  FileText,
  Briefcase,
  Image as ImageIcon,
  CheckSquare,
  MessageSquare,
  Trash2,
  Plus,
  Save,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import { auth, db, handleFirestoreError, OperationType } from "../lib/firebase";
import { translations, SupportedLang } from "../lib/translations";
import {
  WebsiteSettings,
  Package,
  GalleryItem,
  Testimonial,
  Booking,
  BookingStatus,
} from "../types";

const compressImage = (file: File): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 1000;
        const MAX_HEIGHT = 1000;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = () => {
        resolve(event.target?.result as string);
      };
    };
    reader.onerror = () => {
      resolve("");
    };
  });
};

interface AdminPanelProps {
  settings: WebsiteSettings;
  packages: Package[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  bookings: Booking[];
  onRefreshData: () => Promise<void>;
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function AdminPanel({
  settings,
  packages,
  gallery,
  testimonials,
  bookings,
  onRefreshData,
  primaryColor,
  currentLang,
}: AdminPanelProps) {
  // Authentication states
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  // Password change states
  const [newDashboardPassword, setNewDashboardPassword] = useState("");
  const [confirmDashboardPassword, setConfirmDashboardPassword] = useState("");
  const [changePasswordError, setChangePasswordError] = useState("");
  const [changePasswordSuccess, setChangePasswordSuccess] = useState("");
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Active Tab state
  const [activeTab, setActiveTab] = useState<"stats" | "copy" | "packages" | "gallery" | "testimonials" | "bookings" | "security">("stats");

  // Dynamic state forms for updates
  const [settingsForm, setSettingsForm] = useState<WebsiteSettings>({ ...settings });
  
  // Gallery, Packages, Testimonials active selection/new state edits
  const [newGalleryUrl, setNewGalleryUrl] = useState("");
  const [newGalleryTitle, setNewGalleryTitle] = useState("");
  const [newGalleryType, setNewGalleryType] = useState<"image" | "video">("image");

  const [newTestimonialName, setNewTestimonialName] = useState("");
  const [newTestimonialRole, setNewTestimonialRole] = useState("");
  const [newTestimonialText, setNewTestimonialText] = useState("");
  const [newTestimonialRating, setNewTestimonialRating] = useState<number>(5);

  const [newPackageName, setNewPackageName] = useState("");
  const [newPackagePrice, setNewPackagePrice] = useState("");
  const [newPackageDesc, setNewPackageDesc] = useState("");
  const [newPackageFeatures, setNewPackageFeatures] = useState("");

  const [savingStatus, setSavingStatus] = useState<string>("");

  // Monitor Firebase Auth changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setCurrentUser(user);
        setAuthError("");
      } else {
        setCurrentUser(null);
      }
    });
    return () => unsubscribe();
  }, []);

  // Update Settings Form default states when settings document updates
  useEffect(() => {
    setSettingsForm({ ...settings });
  }, [settings]);

  // Auth Submit Handlers
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setIsLoggingIn(true);

    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (err: any) {
      console.error("Login failure: ", err.message);
      setAuthError("Identifiants incorrects ou compte non activé.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleEmailRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setIsLoggingIn(true);

    if (!email.trim() || !email.includes("@")) {
      setAuthError("Saisissez une adresse email valide.");
      setIsLoggingIn(false);
      return;
    }

    if (password.length < 6) {
      setAuthError("Le mot de passe doit contenir au moins 6 caractères.");
      setIsLoggingIn(false);
      return;
    }

    try {
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      // Once created, firebase signs them in automatically of which the onAuthStateChanged triggers
    } catch (err: any) {
      console.error("Registration failure: ", err.message);
      if (err.code === "auth/email-already-in-use") {
        setAuthError("Ce compte administrateur a déjà un mot de passe. Veuillez utiliser le mode de connexion standard.");
      } else {
        setAuthError(err.message || "Échec de création du mot de passe.");
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError("");
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setAuthError("Échec de la connexion Google.");
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setCurrentUser(null);
  };

  // --- Dynamic Operations ---

  // Save Website Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingStatus("Enregistrement...");
    try {
      await setDoc(doc(db, "settings", "general"), settingsForm);
      setSavingStatus("Paramètres enregistrés !");
      await onRefreshData();
      setTimeout(() => setSavingStatus(""), 3000);
    } catch (err: unknown) {
      setSavingStatus("Erreur");
      handleFirestoreError(err, OperationType.WRITE, "settings/general");
    }
  };

  // Add Portfolio Gallery Item
  const handleAddGalleryItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGalleryUrl) return;
    setSavingStatus("Ajout...");
    const itemId = "gal_" + Date.now();
    const itemData: GalleryItem = {
      id: itemId,
      url: newGalleryUrl.trim(),
      type: newGalleryType,
      title: newGalleryTitle.trim() || "Mariage Royal Vision",
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, "gallery", itemId), itemData);
      setNewGalleryUrl("");
      setNewGalleryTitle("");
      setSavingStatus("Élément ajouté !");
      await onRefreshData();
      setTimeout(() => setSavingStatus(""), 3000);
    } catch (err: unknown) {
      setSavingStatus("Erreur");
      handleFirestoreError(err, OperationType.CREATE, `gallery/${itemId}`);
    }
  };

  // Delete Portfolio Gallery Item
  const handleDeleteGalleryItem = async (id: string) => {
    if (!confirm("Voulez-vous supprimer cette œuvre de la galerie ?")) return;
    try {
      setSavingStatus("Suppression...");
      
      // 1. Delete the targeted item
      await deleteDoc(doc(db, "gallery", id));
      
      // 2. Clear out default mock items if a mock item was deleted
      const mockIds = ["gal_1", "gal_2", "gal_3", "gal_4", "gal_5"];
      if (mockIds.includes(id)) {
        for (const item of gallery) {
          if (item.id !== id && mockIds.includes(item.id)) {
            await setDoc(doc(db, "gallery", item.id), item);
          }
        }
      }
      
      await onRefreshData();
      setSavingStatus("");
    } catch (err: unknown) {
      setSavingStatus("");
      handleFirestoreError(err, OperationType.DELETE, `gallery/${id}`);
    }
  };

  // Add Testimonial Item
  const handleAddTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTestimonialName || !newTestimonialText) return;
    setSavingStatus("Ajout...");
    const testimonialId = "test_" + Date.now();
    const testData: Testimonial = {
      id: testimonialId,
      clientName: newTestimonialName.trim(),
      role: newTestimonialRole.trim() || "Mariés",
      text: newTestimonialText.trim(),
      rating: newTestimonialRating,
    };

    try {
      await setDoc(doc(db, "testimonials", testimonialId), testData);
      setNewTestimonialName("");
      setNewTestimonialRole("");
      setNewTestimonialText("");
      setSavingStatus("Témoignage ajouté !");
      await onRefreshData();
      setTimeout(() => setSavingStatus(""), 3000);
    } catch (err: unknown) {
      setSavingStatus("Erreur");
      handleFirestoreError(err, OperationType.CREATE, `testimonials/${testimonialId}`);
    }
  };

  // Delete Testimonial Item
  const handleDeleteTestimonial = async (id: string) => {
    if (!confirm("Supprimer ce témoignage ?")) return;
    try {
      setSavingStatus("Suppression...");
      
      // 1. Delete the targeted item
      await deleteDoc(doc(db, "testimonials", id));
      
      // 2. Clear out default mock items if a mock item was deleted
      const mockIds = ["test_1", "test_2", "test_3"];
      if (mockIds.includes(id)) {
        for (const item of testimonials) {
          if (item.id !== id && mockIds.includes(item.id)) {
            await setDoc(doc(db, "testimonials", item.id), item);
          }
        }
      }
      
      await onRefreshData();
      setSavingStatus("");
    } catch (err: unknown) {
      setSavingStatus("");
      handleFirestoreError(err, OperationType.DELETE, `testimonials/${id}`);
    }
  };

  // Change Booking Status
  const handleChangeBookingStatus = async (id: string, nextStatus: BookingStatus) => {
    try {
      await updateDoc(doc(db, "bookings", id), { status: nextStatus });
      await onRefreshData();
    } catch (err: unknown) {
      handleFirestoreError(err, OperationType.UPDATE, `bookings/${id}`);
    }
  };

  // Add Customizable Package
  const handleAddPackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPackageName) return;
    setSavingStatus("Ajout...");
    const pId = "pack_" + Date.now();
    const packPayload: Package = {
      id: pId,
      name: newPackageName.trim(),
      price: "",
      description: newPackageDesc.trim(),
      features: newPackageFeatures
        .split("\n")
        .map((f) => f.trim())
        .filter((f) => f.length > 0),
      order: packages.length + 1,
    };

    try {
      await setDoc(doc(db, "packages", pId), packPayload);
      setNewPackageName("");
      setNewPackagePrice("");
      setNewPackageDesc("");
      setNewPackageFeatures("");
      setSavingStatus("Package créé !");
      await onRefreshData();
      setTimeout(() => setSavingStatus(""), 3000);
    } catch (err: unknown) {
      setSavingStatus("Erreur");
      handleFirestoreError(err, OperationType.CREATE, `packages/${pId}`);
    }
  };

  // Delete Package
  const handleDeletePackage = async (id: string) => {
    if (!confirm("Voulez-vous supprimer ce pack tarifaire ?")) return;
    try {
      setSavingStatus("Suppression...");
      
      // 1. Delete the targeted item
      await deleteDoc(doc(db, "packages", id));
      
      // 2. Clear out default mock items if a mock item was deleted
      const mockIds = ["package_1", "package_2", "package_3"];
      if (mockIds.includes(id)) {
        for (const item of packages) {
          if (item.id !== id && mockIds.includes(item.id)) {
            await setDoc(doc(db, "packages", item.id), item);
          }
        }
      }
      
      await onRefreshData();
      setSavingStatus("");
    } catch (err: unknown) {
      setSavingStatus("");
      handleFirestoreError(err, OperationType.DELETE, `packages/${id}`);
    }
  };

  // Update Password directly
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePasswordError("");
    setChangePasswordSuccess("");
    
    if (!newDashboardPassword) {
      setChangePasswordError("Veuillez saisir un nouveau mot de passe.");
      return;
    }
    if (newDashboardPassword.length < 6) {
      setChangePasswordError("Le mot de passe doit contenir au moins 6 caractères.");
      return;
    }
    if (newDashboardPassword !== confirmDashboardPassword) {
      setChangePasswordError("Les mots de passe ne correspondent pas.");
      return;
    }
    
    setIsChangingPassword(true);
    try {
      if (currentUser) {
        await updatePassword(currentUser, newDashboardPassword);
        setChangePasswordSuccess("Votre mot de passe a été mis à jour avec succès !");
        setNewDashboardPassword("");
        setConfirmDashboardPassword("");
      } else {
        setChangePasswordError("Aucun utilisateur n'est connecté.");
      }
    } catch (err: any) {
      console.error("Password update error:", err);
      if (err.code === "auth/requires-recent-login") {
        setChangePasswordError("Pour des raisons de sécurité, vous devez vous reconnecter récemment pour effectuer cette action. Veuillez vous déconnecter puis vous reconnecter et réessayer.");
      } else {
        setChangePasswordError(err.message || "Échec de la mise à jour du mot de passe.");
      }
    } finally {
      setIsChangingPassword(false);
    }
  };


  // --- Render Authentication Form Gate ---
  if (!currentUser) {
    return (
      <section className="min-h-screen flex items-center justify-center bg-black py-16 px-6 relative">
        <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(ellipse_at_center,rgba(212,175,55,0.15),transparent)]" />
        
        <div className="max-w-md w-full bg-stone-900 border border-stone-800 p-8 sm:p-10 relative">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-amber-500 to-yellow-500" />
          
          <div className="text-center mb-8">
            <div
              className="w-12 h-12 rounded-full border flex items-center justify-center mx-auto mb-4"
              style={{ borderColor: primaryColor, color: primaryColor }}
            >
              <Lock className="w-5 h-5 animate-pulse" />
            </div>
            
            <h3 className="font-serif text-2xl text-white font-bold tracking-widest uppercase">
              {isRegistering ? "CRÉATION ADMIN" : "ADMINISTRATION"}
            </h3>
            <p className="text-stone-500 font-mono text-[9px] tracking-widest uppercase mt-1">
              {isRegistering ? "Initialiser votre mot de passe" : "Accès réservé - Royal Vision"}
            </p>
          </div>

          {authError && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 font-mono text-xs text-center mb-6 leading-tight">
              {authError}
            </div>
          )}

          <form onSubmit={isRegistering ? handleEmailRegister : handleEmailLogin} className="space-y-5">
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                Adresse Email d'Administration
              </label>
              <input
                type="type"
                required
                placeholder="Ex: admin@royal-vision.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-stone-700 bg-stone-950 text-white font-sans text-sm focus:outline-none focus:border-amber-500 transition-colors rounded-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                Mot de Passe {isRegistering && "(6 caractères min)"}
              </label>
              <input
                type="password"
                required
                placeholder="••••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-stone-700 bg-stone-950 text-white font-sans text-sm focus:outline-none focus:border-amber-500 transition-colors rounded-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 bg-gradient-to-r text-black uppercase font-bold text-xs tracking-widest hover:opacity-95 transition-all text-center cursor-pointer rounded-none disabled:opacity-50"
              style={{
                backgroundImage: `linear-gradient(135deg, ${primaryColor} 0%, #B58D24 100%)`,
              }}
            >
              {isLoggingIn 
                ? "Authentification..." 
                : isRegistering 
                  ? "Créer le compte Administrateur" 
                  : "Se connecter par Email"}
            </button>
          </form>

          <div className="text-center mt-4">
            <button
              onClick={() => {
                setIsRegistering(!isRegistering);
                setAuthError("");
                setEmail(""); 
              }}
              className="text-stone-400 hover:text-white font-mono text-[9px] uppercase tracking-wider underline cursor-pointer"
            >
              {isRegistering 
                ? "Déjà configuré ? Retour à la connexion" 
                : "Première connexion ? Créer votre mot de passe"}
            </button>
          </div>

          {!isRegistering && (
            <>
              {/* Fallback Google Authentication option as secondary compliant flow */}
              <div className="relative my-6 flex items-center justify-center">
                <div className="absolute inset-x-0 h-[1px] bg-stone-800" />
                <span className="relative z-10 px-3 bg-stone-900 text-stone-500 font-mono text-[9px] uppercase tracking-widest">
                  OU
                </span>
              </div>

              <button
                onClick={handleGoogleLogin}
                className="w-full py-3 border border-stone-700 hover:border-white text-white uppercase text-xs tracking-widest font-bold bg-transparent transition-all cursor-pointer rounded-none flex items-center justify-center gap-2"
              >
                Google Sign-In
              </button>
            </>
          )}

          <p className="text-center font-mono text-[9px] text-stone-500 tracking-wider leading-relaxed mt-6">
            L'administration de Royal Vision est strictement restreinte aux personnes autorisées.
          </p>
        </div>
      </section>
    );
  }

  // --- Statistics Logic Calculations ---
  const totalBookings = bookings.length;
  const pendingCount = bookings.filter((b) => b.status === BookingStatus.PENDING).length;
  const confirmedCount = bookings.filter((b) => b.status === BookingStatus.CONFIRMED).length;
  const cancelledCount = bookings.filter((b) => b.status === BookingStatus.CANCELLED).length;


  // --- Beautiful Authenticated Panel Layout ---
  return (
    <section className="min-h-screen bg-stone-950 text-stone-300 pt-32 pb-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        
        {/* Dashboard Title & Meta Actions */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12 border-b border-stone-900 pb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5" style={{ color: primaryColor }} />
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-amber-500">
                Espace Super-Administrateur
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-white font-bold tracking-wide">
              Tableau de Bord Royal Vision
            </h2>
            <p className="text-stone-500 text-xs font-mono mt-1">
              Connecté : <span className="text-stone-300">{currentUser.email}</span>
            </p>
          </div>

          <button
            onClick={handleLogout}
            className="px-5 py-2.5 bg-stone-900 border border-stone-850 hover:bg-stone-850 text-white font-bold text-xs tracking-widest uppercase transition-all flex items-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" /> Déconnexion
          </button>
        </div>

        {/* Global Notification Floating State Bar */}
        {savingStatus && (
          <div className="fixed bottom-6 left-6 z-50 bg-stone-900 border border-amber-500/40 text-white py-3 px-6 font-mono text-xs flex items-center gap-3 shadow-2xl">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            {savingStatus}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Side Tabs Selections Navigation */}
          <div className="flex flex-col gap-2">
            {([
              { id: "stats", label: "Statistiques & Activité", icon: TrendingUp },
              { id: "copy", label: "Contenu & Textes Site", icon: FileText },
              { id: "packages", label: "Gestion des Tarifs", icon: Briefcase },
              { id: "gallery", label: "Showcase & Portfolio", icon: ImageIcon },
              { id: "testimonials", label: "Avis Clients", icon: MessageSquare },
              { id: "bookings", label: "Suivi des Réservations", icon: CheckSquare },
              { id: "security", label: "Sécurité & Accès", icon: Lock },
            ] as const).map((tab) => {
              const tabActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center justify-between text-left px-5 py-3.5 uppercase text-[10px] tracking-widest font-bold transition-all duration-300 border cursor-pointer ${
                    tabActive
                      ? "bg-white text-black border-white"
                      : "bg-stone-900/40 border-stone-900 hover:bg-stone-900 text-stone-400 hover:text-white"
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <tab.icon className="w-4 h-4" /> {tab.label}
                  </span>
                  {tab.id === "bookings" && pendingCount > 0 && (
                    <span className="bg-amber-600 text-white text-[9px] font-mono font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                      {pendingCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Selected Navigation Content Render Area */}
          <div className="col-span-1 lg:col-span-3 bg-stone-900/30 border border-stone-900 p-6 sm:p-8 relative">
            
            {/* STATS OVERVIEW PANEL */}
            {activeTab === "stats" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Analyse des KPIs d'Activité
                  </h4>
                  <p className="text-stone-500 text-xs">Vue consolidée en temps réel des réservations enregistrées.</p>
                </div>

                {/* KPI Numeric Metas Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="bg-stone-900 border border-stone-850 p-5 rounded-none">
                    <div className="flex items-center justify-between text-stone-500 mb-2">
                      <span className="font-mono text-[9px] uppercase tracking-widest">Total Demandes</span>
                      <ArrowUpRight className="w-4.5 h-4.5 text-stone-600" />
                    </div>
                    <span className="font-serif text-3xl font-bold text-white">{totalBookings}</span>
                  </div>

                  <div className="bg-stone-900 border border-stone-850 p-5 rounded-none">
                    <div className="flex items-center justify-between text-amber-500 mb-2">
                      <span className="font-mono text-[9px] uppercase tracking-widest">En Attente</span>
                      <Clock className="w-4.5 h-4.5" />
                    </div>
                    <span className="font-serif text-3xl font-bold text-white">{pendingCount}</span>
                  </div>

                  <div className="bg-stone-900 border border-stone-850 p-5 rounded-none">
                    <div className="flex items-center justify-between text-emerald-500 mb-2">
                      <span className="font-mono text-[9px] uppercase tracking-widest">Confirmées</span>
                      <CheckCircle className="w-4.5 h-4.5" />
                    </div>
                    <span className="font-serif text-3xl font-bold text-white">{confirmedCount}</span>
                  </div>

                  <div className="bg-stone-900 border border-stone-850 p-5 rounded-none">
                    <div className="flex items-center justify-between text-red-500 mb-2">
                      <span className="font-mono text-[9px] uppercase tracking-widest">Annulées</span>
                      <XCircle className="w-4.5 h-4.5" />
                    </div>
                    <span className="font-serif text-3xl font-bold text-white">{cancelledCount}</span>
                  </div>
                </div>

                {/* Booking lists highlights */}
                <div className="bg-stone-900/60 border border-stone-850 p-6">
                  <h5 className="font-serif text-white font-bold tracking-wide text-sm mb-4">
                    Statut Récent des Réservations
                  </h5>
                  <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                    {bookings.slice(0, 5).map((booking) => (
                      <div
                        key={booking.id}
                        className="flex justify-between items-center bg-stone-950 p-3 border border-stone-900 hover:border-stone-800"
                      >
                        <div>
                          <span className="font-mono text-[10px] text-stone-500">{booking.id}</span>
                          <span className="block text-white text-xs font-semibold">{booking.fullName}</span>
                        </div>
                        <div className="text-right">
                          <span className="block text-stone-400 text-[10px] font-mono">{booking.eventDate}</span>
                          <span
                            className={`text-[9px] font-mono uppercase tracking-widest px-2 py-0.5 border ${
                              booking.status === BookingStatus.CONFIRMED
                                ? "border-emerald-500/20 text-emerald-400 bg-emerald-500/5"
                                : booking.status === BookingStatus.CANCELLED
                                ? "border-red-500/20 text-red-400 bg-red-500/5"
                                : "border-amber-500/20 text-amber-400 bg-amber-500/5"
                            }`}
                          >
                            {booking.status}
                          </span>
                        </div>
                      </div>
                    ))}
                    {bookings.length === 0 && (
                      <p className="text-stone-500 font-mono text-xs text-center py-6 uppercase">
                        Aucun registre de réservation actif.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}


            {/* WEBSITE COPY MANAGEMENT PANEL */}
            {activeTab === "copy" && (
              <form onSubmit={handleSaveSettings} className="space-y-6 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Textes & Paramètres d'Affichage
                  </h4>
                  <p className="text-stone-500 text-xs">Configurez l'intégralité de la charte de textes de Royal Vision.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Nom de Marque
                    </label>
                    <input
                      type="text"
                      value={settingsForm.websiteName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, websiteName: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Logo Affiché
                    </label>
                    <input
                      type="text"
                      value={settingsForm.logoText}
                      onChange={(e) => setSettingsForm({ ...settingsForm, logoText: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Titre de la Section Héro (Accueil)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.heroTitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heroTitle: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Sous-titre Section Héro (Accueil)
                    </label>
                    <textarea
                      rows={2}
                      value={settingsForm.heroSubtitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heroSubtitle: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Grand Titre À Propos
                    </label>
                    <input
                      type="text"
                      value={settingsForm.aboutTitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, aboutTitle: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Description Détaillée À Propos (Séparez vos paragraphes avec deux retours à la ligne)
                    </label>
                    <textarea
                      rows={5}
                      value={settingsForm.aboutText}
                      onChange={(e) => setSettingsForm({ ...settingsForm, aboutText: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-stone-900/50 p-4 border border-stone-850">
                  <div className="col-span-2">
                    <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                      LIENS COMMERCIAUX & RÉSEAUX
                    </span>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Contact WhatsApp Direct (Format sans + e.g., 8615578369805)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.contactWhatsApp}
                      onChange={(e) => setSettingsForm({ ...settingsForm, contactWhatsApp: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-mono text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Handle Instagram (e.g., royal.vision_)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.contactInstagram}
                      onChange={(e) => setSettingsForm({ ...settingsForm, contactInstagram: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-mono text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-stone-900/50 p-4 border border-stone-850">
                  <div className="col-span-2">
                    <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                      SEO & THÉMATISATION COULEURS
                    </span>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      Code Hex Couleur Principale (Or Royal- e.g., #D4AF37)
                    </label>
                    <input
                      type="text"
                      value={settingsForm.primaryColor}
                      onChange={(e) => setSettingsForm({ ...settingsForm, primaryColor: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-mono text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      SEO Meta-Titre Spécifique
                    </label>
                    <input
                      type="text"
                      value={settingsForm.seoTitle}
                      onChange={(e) => setSettingsForm({ ...settingsForm, seoTitle: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-2">
                      SEO Meta-Description Résumé
                    </label>
                    <textarea
                      rows={2}
                      value={settingsForm.seoDescription}
                      onChange={(e) => setSettingsForm({ ...settingsForm, seoDescription: e.target.value })}
                      className="w-full px-4 py-2 border border-stone-700 bg-stone-950 text-white font-sans text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-white text-black font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Sauvegarder les Paramètres Généraux
                </button>
              </form>
            )}


            {/* DYNAMIC PACKAGES MANAGEMENT PANEL */}
            {activeTab === "packages" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Collections & Tarifs de Prestation
                  </h4>
                  <p className="text-stone-500 text-xs">Créez, modifiez, ou supprimez les collections d'offres.</p>
                </div>

                {/* Form to submit package */}
                <form onSubmit={handleAddPackage} className="bg-stone-900/60 border border-stone-850 p-5 space-y-4">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                    ➕ AJOUTER UNE FORMULE COMMERCIALE
                  </span>

                  <div>
                    <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Nom de la Collection (Basic, Premium ou Gold)</label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Gold: Multi-Camera Cinematic Masterpiece"
                      value={newPackageName}
                      onChange={(e) => setNewPackageName(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Brève Description</label>
                    <input
                      type="text"
                      placeholder="Résumé des bénéfices exclusifs..."
                      value={newPackageDesc}
                      onChange={(e) => setNewPackageDesc(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono uppercase text-[#A8A29E] mb-1">
                      Caractéristiques du Pack (Un élément par ligne)
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Vidéo Complète HD&#10;Prises de vue Drone intégrées&#10;Shooting Album"
                      value={newPackageFeatures}
                      onChange={(e) => setNewPackageFeatures(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-black font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Créer cette Collection
                  </button>
                </form>

                {/* Listing of existing Packages */}
                <div className="space-y-3">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-stone-500 block mb-2">
                    COLLECTIONS ACTUELLEMENT DISPONIBLES ({packages.length})
                  </span>

                  {packages.map((p) => (
                    <div
                      key={p.id}
                      className="bg-stone-900 border border-stone-850 p-4 flex justify-between items-start"
                    >
                      <div>
                        <h5 className="font-serif text-white font-bold text-sm tracking-wide">{p.name}</h5>
                        <p className="text-stone-400 text-xs mt-1 leading-normal max-w-lg">{p.description}</p>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {p.features.map((f, idx) => (
                            <span key={idx} className="bg-stone-950 text-stone-400 text-[9px] px-2 py-0.5 border border-stone-850 font-sans">
                              {f}
                            </span>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => handleDeletePackage(p.id)}
                        className="p-2 text-stone-500 hover:text-red-400 transition-colors cursor-pointer"
                        title="Supprimer la collection"
                      >
                        <Trash2 className="w-4.5 h-4.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}


            {/* GALLERY SHOWCASE PORTFOLIO CONTROL */}
            {activeTab === "gallery" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Showcase & Médias Visuels
                  </h4>
                  <p className="text-stone-500 text-xs">Intégrez de nouveaux souvenirs de mariage à votre carrousel.</p>
                </div>

                {/* Form to submit image/video */}
                <form onSubmit={handleAddGalleryItem} className="bg-stone-900/60 border border-stone-850 p-5 space-y-4">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                    ➕ AJOUTER UN CLICHÉ OU UNE VIDÉO DE LUXE
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Catégorie Média</label>
                      <select
                        value={newGalleryType}
                        onChange={(e) => setNewGalleryType(e.target.value as "image" | "video")}
                        className="w-full py-2 px-3 border border-stone-700 bg-stone-950 text-stone-300 text-xs focus:outline-none focus:border-amber-500 rounded-none"
                      >
                        <option value="image">Photographie d'Art</option>
                        <option value="video">Cinéma / Vidéo YouTube-Vimeo Link</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Titre de l'Œuvre</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Rituel de la couronne traditional caftan"
                        value={newGalleryTitle}
                        onChange={(e) => setNewGalleryTitle(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">
                      {newGalleryType === "image" ? "Sélectionner un fichier (Depuis votre appareil / Galerie)" : "URL Directe de la Source Média"}
                    </label>
                    
                    {newGalleryType === "image" ? (
                      <div className="space-y-3">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const compressed = await compressImage(file);
                                setNewGalleryUrl(compressed);
                              } catch (err) {
                                console.error("Error compressing image, falling back to FileReader", err);
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  setNewGalleryUrl(reader.result as string);
                                };
                                reader.readAsDataURL(file);
                              }
                            }
                          }}
                          className="w-full text-xs text-stone-400 file:mr-4 file:py-2 file:px-4 file:border-0 file:text-xs file:font-mono file:bg-stone-800 file:text-white hover:file:bg-stone-700 font-sans cursor-pointer animate-fadeIn"
                        />
                        {newGalleryUrl && newGalleryUrl.startsWith("data:") && (
                          <div className="mt-2 border border-stone-850 p-2 bg-stone-950 inline-block">
                            <span className="block text-[8px] font-mono text-[#A8A29E] uppercase mb-1">Aperçu de l'image sélectionnée :</span>
                            <img src={newGalleryUrl} alt="Aperçu upload" className="max-h-24 object-contain" referrerPolicy="no-referrer" />
                          </div>
                        )}
                        <div className="relative flex items-center justify-center my-2">
                          <div className="absolute inset-x-0 h-[1px] bg-stone-800" />
                          <span className="relative z-10 px-2 bg-stone-900 text-stone-500 font-mono text-[9px] uppercase">Ou utiliser une URL directe d'image</span>
                        </div>
                        <input
                          type="text"
                          placeholder="Ex: https://images.unsplash.com/photo-X..."
                          value={newGalleryUrl && !newGalleryUrl.startsWith("data:") ? newGalleryUrl : ""}
                          onChange={(e) => setNewGalleryUrl(e.target.value)}
                          className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-stone-300 text-xs font-mono focus:outline-none focus:border-amber-500 rounded-none animate-fadeIn"
                        />
                      </div>
                    ) : (
                      <input
                        type="text"
                        required
                        placeholder="Ex: https://www.youtube.com/watch?v=..."
                        value={newGalleryUrl}
                        onChange={(e) => setNewGalleryUrl(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-stone-300 text-xs font-mono focus:outline-none focus:border-amber-500 rounded-none animate-fadeIn"
                      />
                    )}
                    <p className="text-[9px] text-[#78716C] font-mono mt-1 animate-fadeIn">
                      {newGalleryType === "image" 
                        ? "Sélectionnez une image de votre galerie ou saisissez une URL d'image existante."
                        : "Saisissez un lien de partage de vidéo YouTube/Vimeo."}
                    </p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-black font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Publier l'élément
                  </button>
                </form>

                {/* Grid listing existing items */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {gallery.map((g) => (
                    <div
                      key={g.id}
                      className="bg-stone-905 border border-stone-850 p-3 flex gap-4 items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={g.type === "video" ? "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=150" : g.url}
                          alt="Portfolio Thumbnail"
                          className="w-12 h-12 object-cover border border-stone-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="overflow-hidden">
                          <h6 className="text-white text-xs truncate font-serif font-medium">{g.title}</h6>
                          <span className="font-mono text-[8px] uppercase text-[#A8A29E]">
                            {g.type === "video" ? "Film Cinéma" : "Photo"}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDeleteGalleryItem(g.id)}
                        className="p-1.5 text-stone-500 hover:text-red-400 transition-colors cursor-pointer"
                        title="Retirer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}


            {/* TESTIMONIALS MANAGEMENT */}
            {activeTab === "testimonials" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Gérez les Avis de Vos Couples
                  </h4>
                  <p className="text-stone-500 text-xs">Partagez l'expérience heureuse des couples Royal Vision.</p>
                </div>

                {/* Form to submit testimonial */}
                <form onSubmit={handleAddTestimonial} className="bg-stone-900/60 border border-stone-850 p-5 space-y-4">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                    ➕ AJOUTER UN NOUVEl AVIS CLIENT
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Prénom des Mariés</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Selma & Amin"
                        value={newTestimonialName}
                        onChange={(e) => setNewTestimonialName(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Sous-texte de Statut</label>
                      <input
                        type="text"
                        placeholder="Ex: Traditionnel Elegant Bride"
                        value={newTestimonialRole}
                        onChange={(e) => setNewTestimonialRole(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Évaluation (Étoiles)</label>
                      <select
                        value={newTestimonialRating}
                        onChange={(e) => setNewTestimonialRating(Number(e.target.value))}
                        className="w-full py-2 px-3 border border-stone-700 bg-stone-950 text-stone-300 text-xs focus:outline-none focus:border-amber-500 rounded-none"
                      >
                        <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                        <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                        <option value={3}>⭐⭐⭐ (3/5)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono uppercase text-stone-400 mb-1">Avis Rédigé</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Comment l'équipe Royal Vision a-t-elle immortalisé le plus grand jour de leur vie..."
                      value={newTestimonialText}
                      onChange={(e) => setNewTestimonialText(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-700 bg-stone-950 text-white text-xs focus:outline-none focus:border-amber-500 rounded-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-black font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Enregistrer l'avis
                  </button>
                </form>

                {/* Testimonial listed items */}
                <div className="space-y-3">
                  {testimonials.map((t) => (
                    <div
                      key={t.id}
                      className="bg-stone-900 border border-stone-850 p-4 flex justify-between items-start"
                    >
                      <div>
                        <h6 className="font-serif text-white font-bold text-xs sm:text-sm">{t.clientName}</h6>
                        <span className="font-mono text-[9px] text-[#A8A29E] tracking-wider uppercase block">{t.role}</span>
                        <p className="text-stone-300 text-xs mt-2 italic font-light leading-normal max-w-lg">
                          "{t.text}"
                        </p>
                      </div>

                      <button
                        onClick={() => handleDeleteTestimonial(t.id)}
                        className="p-2 text-stone-500 hover:text-red-400 transition-colors cursor-pointer"
                        title="Retirer l'avis"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}


            {/* BOOKINGS REGISTER LISTS */}
            {activeTab === "bookings" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Registre des Réservations Client
                  </h4>
                  <p className="text-stone-500 text-xs">Gérez les demandes de réservation et modifiez leur état (Confirmé / Annulé).</p>
                </div>

                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                  {bookings.map((b) => (
                    <div
                      key={b.id}
                      className="bg-stone-900 border border-stone-850 p-5 space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row justify-between items-start gap-2 border-b border-stone-850 pb-3">
                        <div>
                          <span className="font-mono text-[10px] bg-stone-950 px-2 py-0.5 border border-stone-800 text-amber-500 uppercase tracking-widest font-bold">
                            {b.id}
                          </span>
                          <h5 className="font-serif text-white font-bold text-sm tracking-wide mt-1.5">{b.fullName}</h5>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleChangeBookingStatus(b.id, BookingStatus.CONFIRMED)}
                            className={`px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest border transition-all cursor-pointer ${
                              b.status === BookingStatus.CONFIRMED
                                ? "bg-emerald-600/20 text-emerald-400 border-emerald-500"
                                : "border-stone-800 text-stone-500 hover:border-stone-600"
                            }`}
                          >
                            Confirmer
                          </button>
                          
                          <button
                            onClick={() => handleChangeBookingStatus(b.id, BookingStatus.CANCELLED)}
                            className={`px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest border transition-all cursor-pointer ${
                              b.status === BookingStatus.CANCELLED
                                ? "bg-red-650/20 text-red-400 border-red-500"
                                : "border-stone-800 text-stone-500 hover:border-stone-600"
                            }`}
                          >
                            Annuler
                          </button>
                        </div>
                      </div>

                      {/* Info coordinates details */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs sm:text-sm">
                        <div>
                          <span className="block text-[9px] font-mono text-stone-500 uppercase">Téléphone WhatsApp</span>
                          <a href={`https://wa.me/${b.phone.replace(/\+/g, "").trim()}`} target="_blank" className="text-white hover:underline transition-all">
                            {b.phone}
                          </a>
                        </div>
                        <div>
                          <span className="block text-[9px] font-mono text-stone-500 uppercase">Date Célébration</span>
                          <span className="text-stone-300 font-medium">{b.eventDate}</span>
                        </div>
                        <div>
                          <span className="block text-[9px] font-mono text-stone-500 uppercase">Lieu Planifié</span>
                          <span className="text-stone-300 font-medium">{b.eventLocation}</span>
                        </div>
                      </div>

                      <div className="bg-stone-950/60 p-3 border border-stone-900 rounded-none text-xs">
                        <span className="block text-[9px] font-mono text-stone-500 uppercase mb-1">Formule Demandée</span>
                        <p className="text-stone-300 font-medium">{b.packageType}</p>
                      </div>

                      {b.notes && (
                        <div className="bg-stone-950/60 p-3 border border-stone-900 rounded-none text-xs sm:text-sm">
                          <span className="block text-[9px] font-mono text-stone-500 uppercase mb-1">Notes Particulières</span>
                          <p className="text-stone-400 font-light italic">"{b.notes}"</p>
                        </div>
                      )}
                    </div>
                  ))}

                  {bookings.length === 0 && (
                    <p className="text-stone-500 font-mono text-xs text-center py-12 uppercase border border-stone-850">
                      Aucune demande de réservation reçue à ce jour.
                    </p>
                  )}
                </div>
              </div>
            )}

            {activeTab === "security" && (
              <div className="space-y-8 animate-fadeIn">
                <div className="border-b border-stone-900 pb-4">
                  <h4 className="font-serif text-white text-xl font-bold tracking-wide">
                    Sécurité, Accès & Mot de Passe
                  </h4>
                  <p className="text-stone-500 text-xs">Modifiez le mot de passe d'administration en toute sécurité sans avoir besoin de l'ancien mot de passe.</p>
                </div>

                <form onSubmit={handleUpdatePassword} className="bg-stone-900/60 border border-stone-850 p-6 space-y-5 max-w-lg">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold block mb-2">
                    🔑 MODIFIER LA CLÉ D'ACCÈS DE L'ADMINISTRATION
                  </span>

                  {changePasswordError && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 font-mono text-xs text-center leading-tight">
                      {changePasswordError}
                    </div>
                  )}

                  {changePasswordSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 font-mono text-xs text-center leading-tight">
                      {changePasswordSuccess}
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-[#A8A29E] mb-2">
                      Nouveau Mot de Passe (min. 6 caractères)
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Saisissez le nouveau mot de passe"
                      value={newDashboardPassword}
                      onChange={(e) => setNewDashboardPassword(e.target.value)}
                      className="w-full px-4 py-3 border border-stone-700 bg-stone-950 text-white font-sans text-sm focus:outline-none focus:border-amber-500 transition-colors rounded-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-[#A8A29E] mb-2">
                      Confirmer le Nouveau Mot de Passe
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Confirmez le nouveau mot de passe"
                      value={confirmDashboardPassword}
                      onChange={(e) => setConfirmDashboardPassword(e.target.value)}
                      className="w-full px-4 py-3 border border-stone-700 bg-stone-950 text-white font-sans text-sm focus:outline-none focus:border-amber-500 transition-colors rounded-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isChangingPassword}
                    className="w-full py-3 bg-white text-black font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isChangingPassword ? "Mise à jour en cours..." : "Sauvegarder le Nouveau Mot de Passe"}
                  </button>
                </form>

                <div className="bg-stone-900/40 p-4 border border-stone-850/50 rounded-none max-w-lg text-xs leading-relaxed text-stone-500">
                  <p className="font-mono text-[9px] uppercase tracking-wider text-stone-400 mb-1">ℹ️ Informations Importantes</p>
                  <p>Comme vous êtes actuellement authentifié en tant que gestionnaire, l'API Firestore et Firebase auth vous permettent de réécrire directement vos coordonnées de sécurité. Aucun ancien mot de passe n'est requis.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
