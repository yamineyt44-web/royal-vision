/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { MessageCircle } from "lucide-react";
import { SupportedLang } from "../lib/translations";

interface FloatingWhatsAppProps {
  contactWhatsApp: string;
  currentLang: SupportedLang;
}

export default function FloatingWhatsApp({ contactWhatsApp, currentLang }: FloatingWhatsAppProps) {
  const whatsappNumber = contactWhatsApp.replace(/\+/g, "").trim() || "8615578369805";
  
  const getLocalizedDefaultText = () => {
    switch (currentLang) {
      case "en":
        return encodeURIComponent("Hello Royal Vision, I am messaging you from your website. I would love to request personalized details for my wedding event.");
      case "ar":
        return encodeURIComponent("مرحباً رويال فيرست، أراسلكم من خلال موقعكم الإلكتروني وأود الاستفسار عن باقات التصوير الفني وحجز موعد لمناسبتي.");
      default:
        return encodeURIComponent("Bonjour Royal Vision, je vous écris depuis votre site internet. Je souhaite obtenir des informations pour célébrer mon union.");
    }
  };

  const link = `https://wa.me/${whatsappNumber}?text=${getLocalizedDefaultText()}`;

  const tooltipText = currentLang === "ar" ? "تحدث معنا مباشرة" : currentLang === "en" ? "Chat with advisor" : "Parler à un conseiller";

  return (
    <div className={`fixed bottom-6 z-40 group ${currentLang === "ar" ? "left-6" : "right-6"}`}>
      {/* Decorative pulse ring waves */}
      <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-30" />
      
      {/* Floating Action Button */}
      <a
        href={link}
        target="_blank"
        rel="noopener noreferrer"
        className="relative flex items-center justify-center w-14 h-14 bg-gradient-to-tr from-emerald-600 to-emerald-400 text-white rounded-full shadow-2xl transition-transform duration-300 group-hover:scale-110 active:scale-95"
        title="WhatsApp"
      >
        <MessageCircle className="w-7 h-7" />
        
        {/* Hover message label box */}
        <span className={`absolute scale-0 transition-all group-hover:scale-100 bg-black border border-white/5 text-stone-300 text-[10px] uppercase font-mono tracking-widest py-2 px-3 whitespace-nowrap shadow-xl
          ${currentLang === "ar" ? "left-16 origin-left" : "right-16 origin-right"}`}
        >
          {tooltipText}
        </span>
      </a>
    </div>
  );
}
