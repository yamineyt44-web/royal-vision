/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Camera, Video, Compass, Layers, Sparkles, Heart } from "lucide-react";
import { translations, SupportedLang } from "../lib/translations";

interface ServicesProps {
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function Services({ primaryColor, currentLang }: ServicesProps) {
  const t = translations[currentLang];

  const getTranslatedServices = () => {
    switch (currentLang) {
      case "en":
        return [
          {
            icon: Camera,
            title: "Prestige Wedding Photography",
            desc: "Unlimited ultra-high-definition coverage of all your precious moments, capturing ancestral wear details, custom cosmetic artwork, and delicate family emotions.",
          },
          {
            icon: Video,
            title: "Global Multi-Camera Cinema",
            desc: "Immersive multi-camera choreography directed by elite cinematographers. Complete edits inclusive of 4K cinematic highlight trailers and raw documentary recordings.",
          },
          {
            icon: Compass,
            title: "Aerial Drone Cinematography",
            desc: "Professional drone operations to record the grandeur of your wedding venue, majestic bridal convoy entries, and deep-angled guest gatherings.",
          },
          {
            icon: Layers,
            title: "Artistic Albums & Memory Boxes",
            desc: "Exquisite layout designs of your chosen portraits printed on Master Fine Art papers, encased in bespoke wooden, silk, or gold-gilded letter boxes.",
          },
          {
            icon: Sparkles,
            title: "Creative Art Direction",
            desc: "Bespoke couple posture coaching, optimal ambient color lights alignment, and persistent creative support on-set to ensure you glow at every pixel angle.",
          },
          {
            icon: Heart,
            title: "Private & Heritage Journeys",
            desc: "Comprehensive custom media coverage of private engagements, traditional henna rituals, royal banquets, and elite personal family celebrations.",
          },
        ];
      case "ar":
        return [
          {
            icon: Camera,
            title: "تصوير فوتوغرافي فاخر",
            desc: "تغطية كاملة بدقة فائقة لكافة تفاصيل الفرح، مع التركيز على رداء العروس التراثي، زينة الحلي والأشكال ونقاء المشاعر العائلية المتبادلة.",
          },
          {
            icon: Video,
            title: "سينما زفاف متعددة الزوايا",
            desc: "تصوير سينمائي احترافي بعدة كاميرات متزامنة بإشراف نخبة من المخرجين. تشمل الخدمة ملخصًا سينمائيًا مبهرًا Teaser بدقة 4K وفيلمًا طويلاً كالعمر.",
          },
          {
            icon: Compass,
            title: "تصوير جوي Drone احترافي",
            desc: "طائرات درون متطورة تلتقط هيبة مكان الحفل، ومواكب العبور المهيبة للعروسين وتجمعات الضيوف المبهرة بهواء الطلق والحدائق.",
          },
          {
            icon: Layers,
            title: "صناعة ألبومات النخبة وصناديق الحفظ",
            desc: "ألبومات صور حِرَفية مطبوعة يدوياً على ورق فني خاص، مغلفة بالحرير الفاخر والكتان مع كتابة الأسماء المذهبة لإرث عائلي ممتد.",
          },
          {
            icon: Sparkles,
            title: "التوجيه والدعم الفني الحصري",
            desc: "مرافقة ذكية وإرشاد لوضعيات التصوير الأكثر أناقة وجاذبية، مع التحكم في الإضاءة لإبراز ملامح الجمال في كل ثانية حية.",
          },
          {
            icon: Heart,
            title: "تصوير المناسبات والتقاليد التراثية",
            desc: "توثيق شامل ومكرس للخطوبة، حفلات الحناء التراثية، السهرات الملكية الكبرى، مع الحفاظ على نفس الشغف والهيبة البصرية المتميزة.",
          },
        ];
      default:
        return [
          {
            icon: Camera,
            title: "Photographie de Prestige",
            desc: "Prises de vues illimitées haute définition de tous vos rituels, captant la somptuosité des Lebssates, les détails du maquillage haute couture, et l'éclat des rituels familiaux.",
          },
          {
            icon: Video,
            title: "Cinéma Global & Multicam",
            desc: "Cadrages multi-caméras assurés par nos cinéastes d'élite. Montage soigné incluant des teasers artistiques 4K ainsi qu'une version longue reprenant chaque discours et émotion.",
          },
          {
            icon: Compass,
            title: "Prises de Vues Aériennes",
            desc: "Pilotage professionnel de drone pour capturer l'immensité de votre domaine de réception, l'arrivée grandiose des mariés et le rassemblement à ciel ouvert de vos convives.",
          },
          {
            icon: Layers,
            title: "Création d'Albums & Souvenirs",
            desc: "Mise en page éditoriale de vos plus magnifiques portraits imprimés sur papier d'art, sublimés dans d'élégants coffrets reliés en soie ou en cuir frappé à vos initiales en or.",
          },
          {
            icon: Sparkles,
            title: "Direction Artistique",
            desc: "Conseils de pose personnalisés, valorisation des jeux de lumières d'ambiance et assistance permanente le jour J pour que vous rayonniez à chaque seconde de tournage.",
          },
          {
            icon: Heart,
            title: "Captation d'Événements Tierces",
            desc: "Couverture exhaustive de vos fiançailles, henné traditionnel, soirées de gala, et anniversaires prestigieux avec le même souci constant de noblesse visuelle.",
          },
        ];
    }
  };

  const services = getTranslatedServices();

  return (
    <section id="services" className="py-28 bg-[#0a0a0a] border-b border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Centered Luxury Header Typography */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400 mb-3">
            {t.services_sub}
          </p>
          <h3 className="font-serif text-3xl sm:text-4xl text-white font-semibold tracking-wide">
            {t.services_title}
          </h3>
          <div className="w-16 h-[1.5px] mx-auto mt-6" style={{ backgroundColor: primaryColor }} />
        </div>

        {/* 3x2 Responsive Service Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((s, idx) => (
            <div
              key={idx}
              className="bg-[#0F0F0F] border border-white/5 p-8 transition-all duration-500 relative group overflow-hidden"
            >
              {/* Corner ambient shine on hover */}
              <div
                className="absolute -top-12 -right-12 w-24 h-24 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-[30px]"
                style={{ backgroundColor: primaryColor }}
              />

              {/* Service Icon Container */}
              <div
                className="w-12 h-12 flex items-center justify-center bg-[#0A0A0A] border border-white/5 text-stone-300 group-hover:text-black transition-all duration-300"
                style={{
                  borderLeftColor: s.icon ? primaryColor : "transparent",
                  borderLeftWidth: "2px",
                }}
              >
                <s.icon className="w-6 h-6 transition-transform duration-500 group-hover:scale-110" />
              </div>

              {/* Headline */}
              <h4 className="font-serif text-white text-lg font-bold uppercase tracking-wide mt-6 mb-3">
                {s.title}
              </h4>

              {/* Describing Paragraph */}
              <p className="text-stone-400 text-xs sm:text-sm leading-relaxed tracking-wide">
                {s.desc}
              </p>

              {/* Bottom Decorative Gold Line */}
              <div
                className="absolute bottom-0 left-0 w-0 h-[1.5px] transition-all duration-500 group-hover:w-full"
                style={{ backgroundColor: primaryColor }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
