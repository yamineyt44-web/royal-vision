/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Mail, Phone, Instagram, MapPin, Calendar, FileText, Send, Sparkles, CheckCircle2, Copy } from "lucide-react";
import { setDoc, doc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { BookingStatus, Booking } from "../types";
import { translations, SupportedLang } from "../lib/translations";

interface ContactProps {
  selectedPackage: string;
  setSelectedPackage: (packageName: string) => void;
  contactWhatsApp: string;
  contactInstagram: string;
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function Contact({
  selectedPackage,
  setSelectedPackage,
  contactWhatsApp,
  contactInstagram,
  primaryColor,
  currentLang,
}: ContactProps) {
  // Booking Form State
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [eventLocation, setEventLocation] = useState("");
  const [notes, setNotes] = useState("");
  
  // Status and Submission flags
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const t = translations[currentLang];

  // Generate dynamic booking numbers
  const generateBookingNumber = () => {
    const chars = "XYZ0123456789";
    let token = "";
    for (let i = 0; i < 4; i++) {
      token += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const currentYear = new Date().getFullYear();
    return `RV-${currentYear}-${token}`;
  };

  const getWhatsAppMessageText = (booking: Booking) => {
    switch (currentLang) {
      case "en":
        return `🌟 *NEW LUXURY BOOKING - ROYAL VISION* 🌟\n\nHello, I have just completed my wedding event booking online!\n\n📌 *Booking Ref:* ${booking.id}\n👤 *Full Name:* ${booking.fullName}\n📞 *WhatsApp Number:* ${booking.phone}\n📅 *Event Date:* ${booking.eventDate}\n📍 *Event Venue/City:* ${booking.eventLocation}\n💎 *Selected Suite:* ${booking.packageType}\n📝 *Creative Notes:* ${booking.notes || "None"}\n\nThank you for checking availability. We look forward to creating stellar memories! ✨`;
      case "ar":
        return `🌟 *طلب حجز ملكي جديد - رويال فيرست* 🌟\n\nمرحباً، لقد أكملت للتو طلب الحجز الخاص بمناسبة زفافي عبر موقعكم الإلكتروني!\n\n📌 *رقم مرجع الحجز:* ${booking.id}\n👤 *الاسم الكامل:* ${booking.fullName}\n📞 *رقم الواتساب:* ${booking.phone}\n📅 *تاريخ المناسبة:* ${booking.eventDate}\n📍 *مكان أو مدينة المناسبة:* ${booking.eventLocation}\n💎 *الباقة المختارة:* ${booking.packageType}\n📝 *ملاحظات خاصة:* ${booking.notes || "لا يوجد"}\n\nيرجى تأكيد توفر الموعد وإرشادنا لخطوات الدفع اللاحقة. شكراً لكم! ✨`;
      default:
        return `🌟 *NOUVELLE RÉSERVATION - ROYAL VISION* 🌟\n\n Bonjour, je viens de finaliser ma réservation en ligne sur votre site internet !\n\n📌 *Numéro de Réservation:* ${booking.id}\n👤 *Nom Complet:* ${booking.fullName}\n📞 *Téléphone:* ${booking.phone}\n📅 *Date de l'Événement:* ${booking.eventDate}\n📍 *Lieu de l'Événement:* ${booking.eventLocation}\n💎 *Formule Sélectionnée:* ${booking.packageType}\n📝 *Notes Particulières:* ${booking.notes || "Aucune note"}\n\nMerci de me confirmer la disponibilité et de m'indiquer la marche à suivre ! ✨`;
    }
  };

  // Auto-redirecting and booking save handler
  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setIsSubmitting(true);

    if (!fullName || !phone || !eventDate || !eventLocation) {
      setErrorMessage(currentLang === "ar" ? "يرجى تعبئة كافة الحقول المطلوبة." : currentLang === "en" ? "Please fill in all required fields." : "Veuillez remplir tous les champs requis.");
      setIsSubmitting(false);
      return;
    }

    const bookingId = generateBookingNumber();

    const bookingPayload: Booking = {
      id: bookingId,
      fullName: fullName.trim(),
      phone: phone.trim(),
      eventDate: eventDate.trim(),
      eventLocation: eventLocation.trim(),
      packageType: selectedPackage || "Non Spécifié",
      notes: notes.trim(),
      status: BookingStatus.PENDING,
      createdAt: new Date().toISOString(),
    };

    const targetCollection = "bookings";

    try {
      // Save directly into the Firestore 'bookings' collection
      await setDoc(doc(db, targetCollection, bookingId), bookingPayload);

      // Create pre-filled WhatsApp text with elegant formatting based on language
      const whatsappText = getWhatsAppMessageText(bookingPayload);

      const whatsappNumberClean = contactWhatsApp.replace(/\+/g, "").trim() || "8615578369805";
      const whatsappUrl = `https://wa.me/${whatsappNumberClean}?text=${encodeURIComponent(whatsappText)}`;

      // Set confirmation state
      setConfirmedBooking(bookingPayload);
      setIsSubmitting(false);

      // Open inside new page or iframe redirection trigger
      window.open(whatsappUrl, "_blank", "noopener,noreferrer");
    } catch (err: unknown) {
      setIsSubmitting(false);
      setErrorMessage(currentLang === "ar" ? "فشل الحجز. يرجى إعادة المحاولة من جديد أو التواصل معنا مباشرة عبر واتساب." : currentLang === "en" ? "Failed to save booking. Please retry or message us on WhatsApp directly." : "Échec de la réservation. Veuillez réessayer ou nous contacter sur WhatsApp.");
      
      // Mandatory wrapper for tracing Firestore operation errors
      handleFirestoreError(err, OperationType.CREATE, `${targetCollection}/${bookingId}`);
    }
  };

  const copyBookingId = () => {
    if (confirmedBooking) {
      navigator.clipboard.writeText(confirmedBooking.id);
    }
  };

  return (
    <section id="contact" className="py-28 bg-[#0a0a0a] border-b border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Header visual cues */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400 mb-3 block">
            {t.contact_sub}
          </p>
          <h3 className="font-serif text-3xl sm:text-4xl text-white font-semibold tracking-wide">
            {t.contact_title}
          </h3>
          <div className="w-16 h-[1.5px] mx-auto mt-6" style={{ backgroundColor: primaryColor }} />
        </div>

        {confirmedBooking ? (
          /* Glamorous Booking Confirmation Page */
          <div className="max-w-2xl mx-auto bg-[#0F0F0F] border border-white/5 p-8 sm:p-12 text-center shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: primaryColor }} />
            
            <div className="flex justify-center mb-6">
              <CheckCircle2 className="w-16 h-16 text-emerald-500 animate-bounce" />
            </div>

            <h4 className="font-serif text-2xl sm:text-3xl text-white font-bold mb-4 tracking-wide block">
              {t.booking_success_title}
            </h4>
            
            <p className="text-stone-300 text-xs sm:text-sm leading-relaxed max-w-md mx-auto mb-8 font-light block">
              {t.booking_success_desc}
            </p>

            {/* Dynamic visual tag for reservation codes */}
            <div className={`bg-black/40 border border-white/5 rounded-none py-4 px-6 flex items-center justify-between max-w-sm mx-auto mb-8 ${currentLang === "ar" ? "flex-row-reverse" : "flex-row"}`}>
              <span className="font-mono text-[10px] uppercase text-stone-500 tracking-wider">
                {t.booking_ref}
              </span>
              <span className="font-mono text-base font-bold text-white tracking-widest block">{confirmedBooking.id}</span>
              <button
                onClick={copyBookingId}
                className="p-1.5 text-stone-400 hover:text-white cursor-pointer"
                title="Copier"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>

            <div className={`space-y-3 max-w-md mx-auto text-left border-t border-white/5 pt-6 mb-8 text-xs sm:text-sm text-stone-400 font-light ${currentLang === "ar" ? "text-right" : "text-left"}`}>
              <p><strong className="text-stone-300 font-medium font-serif">{currentLang === "en" ? "Attendee Name" : currentLang === "ar" ? "اسم صاحب الحاجز" : "Client"} :</strong> {confirmedBooking.fullName}</p>
              <p><strong className="text-stone-300 font-medium font-serif">{currentLang === "en" ? "Date" : currentLang === "ar" ? "تاريخ المناسبة" : "Date Planifiée"} :</strong> {confirmedBooking.eventDate}</p>
              <p><strong className="text-stone-300 font-medium font-serif">{currentLang === "en" ? "Selected Package" : currentLang === "ar" ? "الباقة المختارة" : "Formule Choisie"} :</strong> {confirmedBooking.packageType}</p>
              <p><strong className="text-stone-300 font-medium font-serif">{currentLang === "en" ? "Venue Location" : currentLang === "ar" ? "مكان الحفل" : "Lieu"} :</strong> {confirmedBooking.eventLocation}</p>
            </div>

            <div className={`flex flex-col sm:flex-row gap-4 justify-center ${currentLang === "ar" ? "sm:flex-row-reverse" : "sm:flex-row"}`}>
              <a
                href={`https://wa.me/${contactWhatsApp.replace(/\+/g, "").trim() || "8615578369805"}?text=${encodeURIComponent(getWhatsAppMessageText(confirmedBooking))}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] tracking-wider uppercase transition-all flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 shrink-0" /> {currentLang === "ar" ? "تأكيد واتساب" : currentLang === "en" ? "Open WhatsApp" : "Ouvrir WhatsApp"}
              </a>
              <button
                onClick={() => {
                  setConfirmedBooking(null);
                  setFullName("");
                  setPhone("");
                  setEventDate("");
                  setEventLocation("");
                  setNotes("");
                  setSelectedPackage("");
                }}
                className="px-6 py-3.5 border border-white/10 hover:bg-white hover:text-black hover:border-white text-stone-300 font-bold text-[11px] tracking-wider uppercase transition-all cursor-pointer"
              >
                {t.btn_new_booking}
              </button>
            </div>
          </div>
        ) : (
          /* Normal Form Entry Display */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            
            {/* Elegant Contact Side Information Column */}
            <div className="space-y-12 bg-[#0F0F0F] border border-white/5 p-8 sm:p-12 relative">
              <div className="absolute top-0 left-0 w-12 h-[2px]" style={{ backgroundColor: primaryColor }} />
              
              <div>
                <span className="font-mono text-[9px] uppercase tracking-[0.25em] block" style={{ color: primaryColor }}>
                  {t.contact_studio}
                </span>
                <h4 className="font-serif text-2xl text-white font-bold mt-2 mb-4 tracking-wide block">
                  {t.contact_form_title}
                </h4>
                <p className="text-stone-400 text-xs sm:text-sm leading-relaxed font-light block">
                  {currentLang === "fr" 
                    ? "Prenez rendez-vous directement pour discuter de vos envies de l'art visuel, adapter une clé de style traditionnel à vos tenues et orchestrer l'équipe de tournage."
                    : currentLang === "ar"
                    ? "تفضلوا بحجز موعد تشاوري لمناقشة تطلعاتكم الفنية والجمالية لتوثيق تفاصيل زفافكم ونوعية الفساتين وتنسيق حركات الكاميرا المناسبة."
                    : "Schedule a personalized master council to discuss your visual arts aspirations, coordinate traditional wear styles, and map cue logs with our directors."
                  }
                </p>
              </div>

              <div className="space-y-6">
                {/* Contact Points */}
                <div className={`flex items-start gap-4 ${currentLang === "ar" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className="w-10 h-10 shrink-0 border border-white/5 bg-[#0A0A0A] flex items-center justify-center"
                    style={{ color: primaryColor }}
                  >
                    <Phone className="w-4.5 h-4.5" />
                  </div>
                  <div className={currentLang === "ar" ? "text-right" : "text-left"}>
                    <span className="block text-[9px] font-mono text-stone-500 uppercase tracking-widest">{t.contact_whatsapp_desc}</span>
                    <a
                      href={`https://wa.me/${contactWhatsApp.replace(/\+/g, "").trim() || "8615578369805"}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-white hover:underline font-medium text-xs sm:text-sm tracking-widest block"
                    >
                      {contactWhatsApp || "+86 155 7836 9805"}
                    </a>
                  </div>
                </div>

                <div className={`flex items-start gap-4 ${currentLang === "ar" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className="w-10 h-10 shrink-0 border border-white/5 bg-[#0A0A0A] flex items-center justify-center"
                    style={{ color: primaryColor }}
                  >
                    <Instagram className="w-4.5 h-4.5" />
                  </div>
                  <div className={currentLang === "ar" ? "text-right" : "text-left"}>
                    <span className="block text-[9px] font-mono text-stone-500 uppercase tracking-widest">{t.contact_follow}</span>
                    <a
                      href={`https://instagram.com/${contactInstagram.replace(/@/g, "").trim() || "royal.vision_"}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-white hover:underline font-medium text-xs sm:text-sm tracking-widest block"
                    >
                      @{contactInstagram || "royal.vision_"}
                    </a>
                  </div>
                </div>

                <div className={`flex items-start gap-4 ${currentLang === "ar" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className="w-10 h-10 shrink-0 border border-white/5 bg-[#0A0A0A] flex items-center justify-center"
                    style={{ color: primaryColor }}
                  >
                    <MapPin className="w-4.5 h-4.5" />
                  </div>
                  <div className={currentLang === "ar" ? "text-right" : "text-left"}>
                    <span className="block text-[9px] font-mono text-stone-500 uppercase tracking-widest">{t.contact_zone}</span>
                    <p className="text-stone-300 font-light text-xs sm:text-sm tracking-wide block">
                      {t.contact_zone_val}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamic Interactive Booking Form Fields Column */}
            <form onSubmit={handleBookingSubmit} className="space-y-6">
              {errorMessage && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 font-mono text-xs text-center block">
                  {errorMessage}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                    {t.field_full_name} <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                      👤
                    </span>
                    <input
                      type="text"
                      required
                      placeholder={t.field_full_name_pl}
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-white/5 bg-[#0F0F0F] text-white font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                    {t.field_whatsapp_phone} <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                      <Phone className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="tel"
                      required
                      placeholder={t.field_whatsapp_phone_pl}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-white/5 bg-[#0F0F0F] text-white font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                    {t.field_event_date} <span className="text-red-500">*</span>
                  </label>
                  <div className="relative col-span-1">
                    <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                      <Calendar className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="date"
                      required
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-white/5 bg-[#0F0F0F] text-stone-400 font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                    {t.field_event_location} <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                      <MapPin className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="text"
                      required
                      placeholder={t.field_event_location_pl}
                      value={eventLocation}
                      onChange={(e) => setEventLocation(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-white/5 bg-[#0F0F0F] text-white font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                  {t.field_package_desired}
                </label>
                <select
                  value={selectedPackage}
                  onChange={(e) => setSelectedPackage(e.target.value)}
                  className="w-full py-3 px-4 border border-white/5 bg-[#0F0F0F] text-stone-300 font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                >
                  <option value="">{t.field_package_select}</option>
                  <option value="Pack Bronze: Wedding Film & Photography">{currentLang === "ar" ? "الباقة البرونزية الكلاسيكية" : currentLang === "en" ? "Bronze Classic Package" : "Pack Bronze: Wedding Film & Photography"}</option>
                  <option value="Pack Silver: Elite Cinema & Aerial Footage">{currentLang === "ar" ? "الباقة الفضية النخبة" : currentLang === "en" ? "Silver Elite Package" : "Pack Silver: Elite Cinema & Aerial Footage"}</option>
                  <option value="Pack Royal Gold: Multi-Camera Cinematic Masterpiece">{currentLang === "ar" ? "الباقة الذهبية الملكية VIP" : currentLang === "en" ? "Royal Gold VIP Package" : "Pack Royal Gold: Multi-Camera Cinematic Masterpiece"}</option>
                </select>
              </div>

              <div>
                <label className="block text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-2">
                  {t.field_notes}
                </label>
                <div className="relative">
                  <span className="absolute top-3 left-3 text-stone-500">
                    <FileText className="w-4 h-4" />
                  </span>
                  <textarea
                    rows={4}
                    placeholder={t.field_notes_pl}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-white/5 bg-[#0F0F0F] text-white font-sans text-sm focus:outline-none focus:border-stone-400 transition-colors rounded-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 text-[11px] uppercase tracking-[0.25em] font-semibold border transition-all duration-300 rounded-none cursor-pointer hover:bg-neutral-900 hover:text-white"
                style={{
                  backgroundColor: primaryColor,
                  color: "#000000",
                  borderColor: primaryColor,
                }}
              >
                {isSubmitting ? (
                  <>{currentLang === "ar" ? "جاري الحفظ والتحويل..." : currentLang === "en" ? "Transmitting Reservation..." : "Enregistrement en cours..."}</>
                ) : (
                  <>
                    <Send className={`w-3.5 h-3.5 inline align-text-top ${currentLang === "ar" ? "ml-1.5" : "mr-1.5"}`} /> {t.btn_confirm_booking}
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </section>
  );
}
