/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Star, Quote, Sparkles } from "lucide-react";
import { Testimonial } from "../types";
import { translations, SupportedLang } from "../lib/translations";

interface TestimonialsProps {
  testimonialsList: Testimonial[];
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function Testimonials({ testimonialsList, primaryColor, currentLang }: TestimonialsProps) {
  const t = translations[currentLang];

  const getLocalizedTestimonial = (test: Testimonial) => {
    if (currentLang === "fr") return test;
    
    const lowerName = test.clientName.toLowerCase();
    if (lowerName.includes("sarah") || lowerName.includes("yassine")) {
      return {
        ...test,
        text: currentLang === "ar" 
          ? "رويال فيجن حوّلوا حفل زفافنا لأسطورة! الصور مبهرة ومعدلة بمنتهى الفن والذكاء ودقة الـ 4K كانت تفوق الإعجاب. شكراً لكم!"
          : "Royal Vision converted our royal wedding into a true living artwork! The photos are jaw-dropping and we are endlessly thankful.",
        role: currentLang === "ar" ? "العروسين" : "Bride & Groom"
      };
    } else if (lowerName.includes("rebecca") || lowerName.includes("thomas")) {
      return {
        ...test,
        text: currentLang === "ar"
          ? "أفضل فريق تصوير على الإطلاق! طائرة الدرون وثّقت موكب وصولنا وتفاصيل القاعة الكبرى بشكل رائع وعاطفي جداً."
          : "Best master photography crew ever! The Drone aerial views of our banquet entry were deeply cinematic and emotional.",
        role: currentLang === "ar" ? "العروسين" : "Bride & Groom"
      };
    } else if (lowerName.includes("amina") || lowerName.includes("sofiane")) {
      return {
        ...test,
        text: currentLang === "ar"
          ? "الألبومات المصنوعة يدوياً وصلت مع أسماء مذهبة بصندوق خشبي فاخر. قمة الرقي والاحترافية والتعامل الملكي."
          : "Bespoke handcrafted custom name gilded albums delivered in an elegant wood box. Infinite prestige and nobility.",
        role: currentLang === "ar" ? "حفل زفاف تراثي" : "Heritage Caftan Celebration"
      };
    }
    return test;
  };

  return (
    <section id="testimonials" className="py-28 bg-[#0a0a0a] border-b border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400 mb-3 block">
            {t.testimonials_sub}
          </p>
          <h3 className="font-serif text-3xl sm:text-4xl text-white font-semibold tracking-wide">
            {t.testimonials_title}
          </h3>
          <div className="w-16 h-[1.5px] mx-auto mt-6" style={{ backgroundColor: primaryColor }} />
        </div>

        {/* Dynamic Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonialsList.map((testRaw) => {
            const test = getLocalizedTestimonial(testRaw);
            return (
              <div
                key={test.id}
                className="bg-[#0F0F0F] border border-white/5 p-8 transition-all duration-500 relative group flex flex-col justify-between"
              >
                {/* Floating Quote graphic */}
                <div className={`absolute top-6 opacity-5 group-hover:opacity-10 transition-opacity ${currentLang === "ar" ? "left-6" : "right-6"}`}>
                  <Quote className="w-12 h-12 text-white" />
                </div>

                <div>
                  {/* 5-Star rating evaluation indicators */}
                  <div className="flex items-center gap-1 mb-6">
                    {Array.from({ length: 5 }).map((_, idx) => (
                      <Star
                        key={idx}
                        className={`w-4 h-4 ${
                          idx < test.rating ? "fill-current" : "text-stone-700"
                        }`}
                        style={{ color: idx < test.rating ? primaryColor : undefined }}
                      />
                    ))}
                  </div>

                  {/* Custom feedback message */}
                  <p className="text-stone-300 font-sans text-xs sm:text-sm tracking-wide leading-relaxed font-light italic mb-8">
                    "{test.text}"
                  </p>
                </div>

                {/* Verified couple metadata */}
                <div className={`flex items-center gap-3 border-t border-white/5 pt-6 mt-auto ${currentLang === "ar" ? "flex-row-reverse text-right" : "text-left"}`}>
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center bg-[#0A0A0A] border border-white/5 shrink-0"
                    style={{ color: primaryColor }}
                  >
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-serif text-white font-bold tracking-wide text-xs block">
                      {test.clientName}
                    </h5>
                    <span className="font-mono text-[9px] uppercase tracking-widest text-stone-400 block">
                      {test.role || (currentLang === "ar" ? "العروس والعروسين" : "Bride & Groom")}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}

          {testimonialsList.length === 0 && (
            <div className="col-span-full py-16 text-center bg-[#0F0F0F] border border-white/5">
              <p className="text-stone-500 text-xs sm:text-sm tracking-widest uppercase font-mono block">
                {t.testimonials_empty}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
