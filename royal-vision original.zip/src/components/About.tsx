/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Sparkles, Award, Camera, Heart, Film } from "lucide-react";
import { translations, SupportedLang } from "../lib/translations";

interface AboutProps {
  title: string;
  aboutText: string;
  primaryColor: string;
  currentLang: SupportedLang;
}

export default function About({ title, aboutText, primaryColor, currentLang }: AboutProps) {
  const t = translations[currentLang];

  const highlights = [
    {
      icon: Camera,
      title: t.highlight_excellence_title,
      desc: t.highlight_excellence_desc,
    },
    {
      icon: Film,
      title: t.highlight_discretion_title,
      desc: t.highlight_discretion_desc,
    },
    {
      icon: Award,
      title: t.highlight_noblesse_title,
      desc: t.highlight_noblesse_desc,
    },
  ];

  return (
    <section id="about" className="py-28 bg-[#0A0A0A] border-b border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Aesthetic Luxury Frame Layout for Images */}
          <div className="relative">
            {/* Main Image Layer (Bridal Ornaments / Traditional Caftan Motif) */}
            <div className="relative z-10 border border-white/5 p-3 bg-[#0F0F0F] backdrop-blur-sm">
              <img
                src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&q=80&w=1200"
                alt="Mariée élégante Royal Vision"
                className="w-full aspect-[4/5] object-cover filter brightness-[0.8] contrast-105"
                referrerPolicy="no-referrer"
              />
              {/* Image signature watermark matching our real image tags */}
              <div className={`absolute bottom-6 bg-black/90 backdrop-blur-sm px-5 py-2.5 border border-white/5 text-right ${currentLang === "ar" ? "left-6" : "right-6"}`}>
                <span className="font-serif text-[10px] uppercase text-white font-semibold tracking-wider block">
                  ROYAL VISION
                </span>
                <span className="block text-[8px] font-mono uppercase text-stone-400 mt-0.5 tracking-widest">
                  {currentLang === "ar" ? "فن التصوير الفوتوغرافي" : "L'ART DE LA PHOTO"}
                </span>
              </div>
            </div>

            {/* Back Gold Textured Accent frame */}
            <div
              className={`absolute -top-6 bottom-6 right-6 border z-0 pointer-events-none ${currentLang === "ar" ? "-right-6 left-6" : "-left-6"}`}
              style={{ borderColor: `${primaryColor}20` }}
            />
            
            {/* Ambient luxury glow bubble */}
            <div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full blur-[100px] pointer-events-none z-0 opacity-80"
              style={{ backgroundColor: `${primaryColor}08` }}
            />
          </div>

          {/* About us narrative column */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5" style={{ color: primaryColor }} />
              <span className="font-mono text-[10px] uppercase tracking-[0.4em] text-stone-400">
                {t.about_sub}
              </span>
            </div>

            <h3 className="font-serif text-2xl sm:text-4xl lg:text-5xl text-white font-semibold tracking-wide leading-tight mb-8">
              {currentLang === "fr" && title ? title : t.about_title}
            </h3>

            <div className="space-y-6 text-stone-300 font-sans text-sm sm:text-base leading-relaxed tracking-wide">
              {aboutText && currentLang === "fr" ? (
                aboutText.split("\n\n").map((p, idx) => <p key={idx}>{p}</p>)
              ) : (
                t.about_text.split("\n\n").map((p, idx) => <p key={idx}>{p}</p>)
              )}
            </div>

            {/* Structured Value Props List */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12 border-t border-white/5 pt-8">
              {highlights.map((h, idx) => (
                <div key={idx} className="flex flex-col gap-2">
                  <div
                    className={"w-10 h-10 flex items-center justify-center bg-[#0F0F0F] border border-white/5"}
                    style={{ color: primaryColor }}
                  >
                    <h.icon className="w-5 h-5" />
                  </div>
                  <h4 className="text-white text-xs uppercase tracking-widest font-bold mt-2">
                    {h.title}
                  </h4>
                  <p className="text-stone-400 text-xs leading-relaxed">{h.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
