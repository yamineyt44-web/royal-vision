/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Menu, X, Crown, Settings } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { translations, SupportedLang } from "../lib/translations";

interface HeaderProps {
  logoText: string;
  primaryColor: string;
  onNavigateToAdmin: () => void;
  isAdminMode: boolean;
  onExitAdmin: () => void;
  currentLang: SupportedLang;
  onLanguageChange: (lang: SupportedLang) => void;
}

export default function Header({
  logoText,
  primaryColor,
  onNavigateToAdmin,
  isAdminMode,
  onExitAdmin,
  currentLang,
  onLanguageChange,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    if (isAdminMode) {
      onExitAdmin();
      // Wait slightly for exit state modification before scrolling
      setTimeout(() => {
        const element = document.getElementById(id);
        element?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      const element = document.getElementById(id);
      element?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const t = translations[currentLang];

  const navLinks = [
    { label: t.nav_home, id: "home" },
    { label: t.nav_about, id: "about" },
    { label: t.nav_services, id: "services" },
    { label: t.nav_packages, id: "packages" },
    { label: t.nav_gallery, id: "gallery" },
    { label: t.nav_testimonials, id: "testimonials" },
    { label: t.nav_contact, id: "contact" },
  ];

  return (
    <header
      id="main-nav-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled
          ? "bg-[#0A0A0A]/95 backdrop-blur-md py-4 border-b border-white/5"
          : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Luxury Logo Branding */}
        <div
          onClick={() => scrollToSection("home")}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative flex flex-col justify-center items-start leading-none">
            <span
              className="text-[10px] uppercase tracking-[0.4em] font-semibold mb-1"
              style={{ color: primaryColor }}
            >
              {t.the_premiere}
            </span>
            <span className="text-2xl font-serif tracking-widest uppercase text-white font-medium">
              {logoText || "ROYAL VISION"}
            </span>
          </div>
        </div>

        {/* Desktop Navigation Link Hierarchy */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollToSection(link.id)}
              className="text-stone-300 text-[11px] uppercase tracking-[0.15em] hover:text-white transition-colors duration-300 relative py-1 group cursor-pointer font-medium"
            >
              {link.label}
              <span
                className="absolute bottom-0 left-0 w-0 h-[1px] transition-all duration-350 group-hover:w-full"
                style={{ backgroundColor: primaryColor }}
              />
            </button>
          ))}
        </nav>

        {/* Header Right Segment CTA */}
        <div className="hidden lg:flex items-center gap-6">
          
          {/* Elegant inline Language triggers on top right next to CTA */}
          <div className="flex items-center gap-3.5 border-r border-white/10 pr-6 mr-1 font-mono text-[10px]">
            {(["fr", "en", "ar"] as SupportedLang[]).map((lang) => (
              <button
                key={lang}
                onClick={() => onLanguageChange(lang)}
                className={`transition-all uppercase tracking-widest cursor-pointer font-semibold py-1.5 ${
                  currentLang === lang ? "text-white scale-110 font-bold" : "text-stone-500 hover:text-stone-300"
                }`}
                style={currentLang === lang ? { color: primaryColor } : {}}
              >
                {lang === "ar" ? "AR" : lang}
              </button>
            ))}
          </div>

          {isAdminMode ? (
            <button
              onClick={onExitAdmin}
              className="text-stone-300 text-[11px] uppercase tracking-[0.2em] font-medium border border-white/10 px-5 py-2.5 hover:bg-white hover:text-black transition-all cursor-pointer"
            >
              {t.btn_back_site}
            </button>
          ) : (
            <button
              onClick={() => onNavigateToAdmin()}
              className="p-2 text-stone-400 hover:text-white transition-colors cursor-pointer"
              title="Espace Admin"
            >
              <Settings className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={() => scrollToSection("contact")}
            className="px-8 py-3 border text-[11px] uppercase tracking-[0.2em] font-semibold transition-all duration-300 rounded-none cursor-pointer hover:bg-white hover:text-black"
            style={{
              borderColor: primaryColor,
              color: primaryColor,
            }}
          >
            {t.btn_reserve}
          </button>
        </div>

        {/* Mobile Menu Trigger */}
        <div className="flex items-center lg:hidden gap-3">
          {isAdminMode && (
            <button
              onClick={onExitAdmin}
              className="text-[10px] text-stone-300 border border-stone-700 px-2 py-1 uppercase"
            >
              Site
            </button>
          )}
          <button
            onClick={() => onNavigateToAdmin()}
            className="p-1 text-stone-400"
            title="Espace Admin"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-stone-300 focus:outline-none cursor-pointer"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#0A0A0A] border-b border-white/5"
          >
            <div className="px-6 py-8 flex flex-col gap-5">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left text-stone-300 hover:text-white transition-colors text-xs font-semibold tracking-[0.25em] uppercase cursor-pointer py-1"
                >
                  {link.label}
                </button>
              ))}

              <div className="h-[1px] bg-white/5 my-2" />

              {/* Mobile Language Selector inside drawer */}
              <div className="flex flex-col gap-2 py-1">
                <span className="text-[9px] font-mono uppercase text-stone-500 tracking-widest">Langue / Language :</span>
                <div className="flex items-center gap-3">
                  {(["fr", "en", "ar"] as SupportedLang[]).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => {
                        onLanguageChange(lang);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`px-3 py-1.5 transition-all text-[11px] font-mono uppercase tracking-widest border ${
                        currentLang === lang ? "border-white text-white font-semibold bg-white/5" : "border-white/5 text-stone-500"
                      }`}
                      style={currentLang === lang ? { borderColor: primaryColor, color: primaryColor } : {}}
                    >
                      {lang === "ar" ? "العربية" : lang.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="h-[1px] bg-white/5 my-1" />

              <button
                onClick={() => scrollToSection("contact")}
                className="w-full text-center py-3.5 text-xs font-semibold tracking-[0.2em] uppercase border cursor-pointer hover:bg-white hover:text-black transition-all"
                style={{
                  borderColor: primaryColor,
                  color: primaryColor,
                }}
              >
                {t.btn_reserve}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
