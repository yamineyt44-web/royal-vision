/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Camera, Calendar, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { translations, SupportedLang } from "../lib/translations";

interface HeroProps {
  title: string;
  subtitle: string;
  primaryColor: string;
  onBookClick: () => void;
  currentLang: SupportedLang;
}

export default function Hero({ title, subtitle, primaryColor, onBookClick, currentLang }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const t = translations[currentLang];

  const slides = [
    {
      image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=2000",
      tag: currentLang === "ar" ? "تنسيق فني فاخر" : currentLang === "en" ? "HAUTE COUTURE ORCHESTRATION" : "ORCHESTRATION HAUTE COUTURE",
      heading: currentLang === "ar" ? "توثيق جوهر وجاذبية أجمل لحظات العمر" : currentLang === "en" ? "Capturing the Essence of Your Most Beautiful Moments" : "Capturer l'Essence de Vos Plus Beaux Instants",
      desc: currentLang === "ar" ? "كل ابتسامة وكل نظرة حب نادرة تُخلّد بعدسة سينمائية رفيعة المستوى لتبقى للأبد." : currentLang === "en" ? "Every smile, every precious look immortalized under a prestigious cinematic eye." : "Chaque sourire, chaque regard précieux immortalisé sous un oeil cinématographique prestigieux.",
    },
    {
      image: "https://images.unsplash.com/photo-1591604466107-ec97de577aff?auto=format&fit=crop&q=80&w=2000",
      tag: currentLang === "ar" ? "فن البورتريه وتفاصيل زينة العروس" : currentLang === "en" ? "THE ART OF PORTRAIT & BRIDAL DETAILS" : "L'ART DU PORTRAIT & MAKEUP",
      heading: currentLang === "ar" ? "دقة فائقة تهتم بأدق التفاصيل والجمال" : currentLang === "en" ? "Perfection in every intricate detail" : "La perfection dans les moindres détails",
      desc: currentLang === "ar" ? "تصوير فني دقيق يبرز بريق العروس وجمال فستانها ومجوهراتها التراثية." : currentLang === "en" ? "Fine art macro photography highlighting the bride's radiance and the purity of ornaments." : "Photographie artistique macro mettant en lumière l'éclat de la mariée et la pureté des ornements.",
    },
    {
      image: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&q=80&w=2000",
      tag: currentLang === "ar" ? "أفلام زفاف تضاهي هوليوود بدقة وإبهار" : currentLang === "en" ? "Elite Cinematic Screenplays 4K" : "SOUVENIRS CINÉMATOGRAPHIQUES BEYOND 4K",
      heading: currentLang === "ar" ? "إنتاج وإخراج أفلام زفاف متميزة بنخبة من الفنيين" : currentLang === "en" ? "Production of elite wedding films" : "Production de films de mariage d'élite",
      desc: currentLang === "ar" ? "لقطات طيران احترافية بطائرات درون وكاميرات متعددة ومونتاج سينمائي مبهر." : currentLang === "en" ? "Dynamic drone footage, multiple camera angles, and festival-grade storytelling edits." : "Captations dynamiques de drone, caméras multiples, et montage digne des plus grands festivals.",
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [slides.length]);

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  // Safe fallback if title/subtitle loaded are customized and in French, but let translations rule if in AR/EN to keep experience luxurious
  const currentHeading = currentSlide === 0
    ? (currentLang === "fr" ? title : t.hero_title)
    : slides[currentSlide].heading;

  const currentDesc = currentSlide === 0
    ? (currentLang === "fr" ? subtitle : t.hero_subtitle)
    : slides[currentSlide].desc;

  return (
    <section id="home" className="relative h-screen w-full bg-black overflow-hidden">
      {/* Dynamic Slide Carrier */}
      <div className="absolute inset-0 w-full h-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="absolute inset-0 w-full h-full"
          >
            {/* Slide Image Background */}
            <img
              src={slides[currentSlide].image}
              alt="Luxury wedding backdrop"
              className="w-full h-full object-cover brightness-[0.35]"
              referrerPolicy="no-referrer"
            />
            {/* Rich gold and dark overlay vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-stone-950/40" />
            <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-transparent to-stone-950/10" />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Floating Sparkles Layout Decorator */}
      <div className="absolute inset-0 pointer-events-none opacity-40 mix-blend-color-dodge">
        <div className="absolute top-1/4 left-1/3 w-96 h-96 rounded-full bg-amber-500/10 blur-[130px] animate-pulse" />
        <div className="absolute bottom-1/3 right-1/4 w-96 h-96 rounded-full bg-yellow-500/10 blur-[150px] animate-pulse" />
      </div>

      {/* Content Center Overlays */}
      <div className="absolute inset-0 flex flex-col justify-center max-w-7xl mx-auto px-6 z-10 pt-20">
        <div className="max-w-3xl">
          {/* Elegant Ribbon Tag */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex items-center gap-3 mb-6"
          >
            <span className="h-[1px] w-8" style={{ backgroundColor: primaryColor }} />
            <span
              className="font-mono text-[10px] tracking-[0.4em] uppercase"
              style={{ color: primaryColor }}
            >
              {slides[currentSlide].tag}
            </span>
          </motion.div>

          {/* Majestic Hero Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="font-serif text-3xl sm:text-5xl md:text-6xl lg:text-7xl text-white tracking-wide leading-tight mb-6 font-semibold"
          >
            {currentHeading}
          </motion.h2>

          {/* Captivating Descriptive Paragraph */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="text-stone-300 font-sans text-sm sm:text-base md:text-lg tracking-wide leading-relaxed max-w-2xl mb-10"
          >
            {currentDesc}
          </motion.p>

          {/* Action Call to Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="flex flex-wrap gap-4 sm:gap-6"
          >
            <button
              onClick={onBookClick}
              className="px-10 py-4.5 text-[11px] uppercase tracking-[0.25em] font-semibold border transition-all duration-300 cursor-pointer flex items-center gap-2.5 hover:bg-white hover:text-black"
              style={{
                borderColor: primaryColor,
                color: primaryColor,
              }}
            >
              <Calendar className="w-4 h-4" /> {t.btn_book_pack}
            </button>
            <button
              onClick={() => {
                document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-10 py-4.5 text-[11px] uppercase tracking-[0.25em] font-semibold text-white border border-white/10 hover:border-white/40 hover:bg-white/5 transition-all duration-300 cursor-pointer flex items-center gap-2.5 group bg-black/40 backdrop-blur-sm"
            >
              {t.btn_discover_services}
              <ArrowRight
                className={`w-4 h-4 transition-transform ${currentLang === "ar" ? "group-hover:-translate-x-1 rotate-180" : "group-hover:translate-x-1"}`}
                style={{ color: primaryColor }}
              />
            </button>
          </motion.div>
        </div>
      </div>

      {/* Manual Slide Toggles */}
      <div className={`absolute bottom-8 flex items-center gap-3 z-10 ${currentLang === "ar" ? "left-6 sm:left-12" : "right-6 sm:right-12"}`}>
        <button
          onClick={handlePrev}
          className="p-3 border border-stone-850 bg-black/60 backdrop-blur-md text-stone-400 hover:text-white transition-all cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-xs font-mono text-stone-500 tracking-wider">
          <span className="text-white">{(currentSlide + 1).toString().padStart(2, "0")}</span> /{" "}
          {slides.length.toString().padStart(2, "0")}
        </div>
        <button
          onClick={handleNext}
          className="p-3 border border-stone-850 bg-black/60 backdrop-blur-md text-stone-400 hover:text-white transition-all cursor-pointer"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Aesthetic Bottom Border Mask */}
      <div className="absolute bottom-0 left-0 w-full h-12 bg-gradient-to-t from-stone-950 to-transparent pointer-events-none" />
    </section>
  );
}
