/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { collection, getDocs, doc, getDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "./lib/firebase";
import {
  WebsiteSettings,
  Package,
  GalleryItem,
  Testimonial,
  Booking,
} from "./types";
import { translations, SupportedLang } from "./lib/translations";

// Import Custom Sub-Components
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Packages from "./components/Packages";
import Gallery from "./components/Gallery";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import FloatingWhatsApp from "./components/FloatingWhatsApp";
import AdminPanel from "./components/AdminPanel";

export default function App() {
  // Navigation Administrator State
  const [isAdminMode, setIsAdminMode] = useState(false);

  // Core Multi-language Selection State
  const [currentLang, setCurrentLang] = useState<SupportedLang>(
    (localStorage.getItem("royal_vision_lang") as SupportedLang) || "fr"
  );

  const handleLanguageChange = (lang: SupportedLang) => {
    setCurrentLang(lang);
    localStorage.setItem("royal_vision_lang", lang);
  };

  // Core Data States
  const [settings, setSettings] = useState<WebsiteSettings>({
    websiteName: "Royal Vision",
    logoText: "Royal Vision",
    heroTitle: "L'Art de la Photo & Cadrage de Mariage",
    heroSubtitle: "Sublimez chacun de vos rituels d'amour par un regard cinématographique d'exception, d'élégance et de tradition séculaire.",
    aboutTitle: "Chaque Émotion Gravée Pour l'Éternité",
    aboutText: "Depuis plus d'une décennie, Royal Vision orchestre et immortalise les noces les plus spectaculaires.\n\nNotre mission consiste à s'imprégner de l'atmosphère féerique de votre célébration pour en restituer toute la noblesse, à travers des portraits ciselés comme des bijoux, des prises de vue aériennes par drone majestueuses, et des films cinématographiques multi-caméras qui racontent l'authentique poésie de votre amour.\n\nDe la finesse du maquillage artistique capturé en macro gros plans, jusqu'aux panoramas spectaculaires de l'entrée majestueuse des mariés en tenues traditionnelles, nous scellons vos moments uniques avec un équipement de pointe et une sensibilité d'artisans d'art.",
    contactWhatsApp: "+8615578369805",
    contactInstagram: "royal.vision_",
    primaryColor: "#C5A059",
    darkBgColor: "#0A0A0A",
    seoTitle: "Royal Vision - Photographie & Cinématographie de Mariage de Prestige",
    seoDescription: "Reportages photographiques illimités de prestige, films de mariage multicam 4K d'élite, captations drone et création d'albums d'art sur-mesure.",
  });

  const [packages, setPackages] = useState<Package[]>([
    {
      id: "package_1",
      name: "Basic: Wedding Film & Photography",
      price: "",
      description: "Parfaite couverture photographique et vidéo de tous les moments clés de votre grand jour.",
      features: [
        "Vidéo Global Full HD (Enregistrement de tous les événements)",
        "Shooting Photo Global Illimité (Haute Définition)",
        "Toutes les photos livrées en coffret clé USB Signature",
        "Album de Luxe personnalisé (100 Photos au format 13x18)",
        "Superbe Agrandissement Photo d'Art (30x40)"
      ],
      order: 1,
    },
    {
      id: "package_2",
      name: "Premium: Elite Cinema & Aerial Footage",
      price: "",
      description: "Une formule d'exception incluant prises de drone aériennes régulières et un Best-Of cinématographique.",
      features: [
        "Photo de Signature haut de gamme sur support d'accueil d'entrée",
        "Vidéo Globale Full HD avec montage moderne",
        "Best-Of Cinématique en 4K (Highlight d'environ 7 minutes)",
        "Prises de vues aériennes spectaculaires par Drone",
        "Album de Prestige personnalisé (200 Photos au format 15x21)",
        "Shooting Photos Professionnel Illimité",
        "Coffret Clé USB Signature & Galerie en ligne sécurisée",
        "Deux magnifiques Agrandissements Photos d'Art (30x40)"
      ],
      order: 2,
    },
    {
      id: "package_3",
      name: "Gold: Multi-Camera Cinematic Masterpiece",
      price: "",
      description: "L'excellence suprême absolue. Une production digne du cinéma, pilotée par trois cadreurs dédiés.",
      features: [
        "Photo de Signature sur grand chevalet d'accueil d'époque",
        "Vidéo Globale Multicam (Production multi-caméras simultanées)",
        "Enregistrement Full HD double caméras mobiles fluides",
        "Best-Of Cinématique en 4K & long-métrage final complet",
        "Prises de vues régulières par Drone de jour comme de nuit",
        "Shooting Photos Professionnel Double Illimité (Deux photographes)",
        "Coffret Bois Précieux personnalisé, clé USB Signature & Google Drive",
        "Merveilleux Album de Prestige personnalisé (200 Photos au format 15x21)",
        "Agrandissement Photo d'Art Prestige XXL (30x40 encapsulé)"
      ],
      order: 3,
    },
  ]);

  const [gallery, setGallery] = useState<GalleryItem[]>([
    {
      id: "gal_1",
      url: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=1200",
      type: "image",
      title: "Cérémonie d'Éclats sous Lustre de Cristal",
      createdAt: new Date().toISOString(),
    },
    {
      id: "gal_2",
      url: "https://images.unsplash.com/photo-1591604466107-ec97de577aff?auto=format&fit=crop&q=80&w=1200",
      type: "image",
      title: "L'art délicat du maquillage de mariée Prestige",
      createdAt: new Date().toISOString(),
    },
    {
      id: "gal_3",
      url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&q=80&w=1200",
      type: "image",
      title: "Symphonie de Blanc et d'Ornements",
      createdAt: new Date().toISOString(),
    },
    {
      id: "gal_4",
      url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&q=80&w=1200",
      type: "image",
      title: "Équipe Royal Vision en pleine captation d'un instant sacré",
      createdAt: new Date().toISOString(),
    },
    {
      id: "gal_5",
      url: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&q=80&w=1200",
      type: "image",
      title: "L'Entrée Triomphale Royale de la Mariée",
      createdAt: new Date().toISOString(),
    }
  ]);

  const [testimonials, setTestimonials] = useState<Testimonial[]>([
    {
      id: "test_1",
      clientName: "Selma & Amin",
      role: "Mariés Époustouflants de Marrakech",
      text: "Un travail d'orfèvre unique ! Chaque regard complice, l'éclat chatoyant de nos tenues de fête, et l'émotion de notre échange d'alliances ont été capturés avec une finesse incroyable.",
      rating: 5,
    },
    {
      id: "test_2",
      clientName: "Kenza & Mehdi",
      role: "Couple Élégant de Paris-Rabat",
      text: "C'est bien plus qu'un simple reportage de mariage, c'est un véritable chef-d'œuvre de cinéma ! Le drone restitue avec grandeur la beauté de notre domaine, et l'équipe multicam était d'une discrétion et d'une rigueur absolue.",
      rating: 5,
    },
    {
      id: "test_3",
      clientName: "Sofia & Youssef",
      role: "Mariés de Prestige",
      text: "Un grand merci à Royal Vision ! Le portrait macro pour le maquillage de noce est spectaculaire, et le coffret en cuir orne fièrement notre salon. Nos familles sont conquises.",
      rating: 5,
    },
  ]);

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [selectedPackage, setSelectedPackage] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  // --- Read Dynamic Collections from Live Firestore ---
  const loadDatabaseData = async () => {
    setIsLoading(true);
    try {
      // 1. Fetch settings general document
      const settingsDocRef = doc(db, "settings", "general");
      const settingsSnap = await getDoc(settingsDocRef);
      if (settingsSnap.exists()) {
        setSettings(settingsSnap.data() as WebsiteSettings);
      }

      // Fetch lists to detect initialization
      const packsSnap = await getDocs(collection(db, "packages"));
      const gallerySnap = await getDocs(collection(db, "gallery"));
      const testSnap = await getDocs(collection(db, "testimonials"));

      // Determine database status and persist the active state flag
      const hasInitializedDb = settingsSnap.exists() || 
                               !packsSnap.empty || 
                               !gallerySnap.empty || 
                               !testSnap.empty || 
                               localStorage.getItem("royal_vision_db_active") === "true";
      if (hasInitializedDb) {
        localStorage.setItem("royal_vision_db_active", "true");
      }

      // 2. Load Packages List or Handle Empty State
      if (!packsSnap.empty) {
        const customPacks: Package[] = [];
        packsSnap.forEach((doc) => {
          const data = doc.data() as Package;
          let name = data.name;
          const lower = name.toLowerCase();
          if (lower.includes("bronze") || lower.includes("basic") || data.id === "package_1" || data.order === 1) {
            name = "Basic: Wedding Film & Photography";
          } else if (lower.includes("silver") || lower.includes("premium") || data.id === "package_2" || data.order === 2) {
            name = "Premium: Elite Cinema & Aerial Footage";
          } else if (lower.includes("gold") || lower.includes("vip") || data.id === "package_3" || data.order === 3) {
            name = "Gold: Multi-Camera Cinematic Masterpiece";
          }
          customPacks.push({
            ...data,
            name,
            price: "", // Dynamically sanitize price
          });
        });
        setPackages(customPacks.sort((a, b) => a.order - b.order));
      } else if (hasInitializedDb) {
        setPackages([]);
      }

      // 3. Load Gallery Items List or Handle Empty State
      if (!gallerySnap.empty) {
        const customGallery: GalleryItem[] = [];
        gallerySnap.forEach((doc) => {
          customGallery.push(doc.data() as GalleryItem);
        });
        setGallery(customGallery);
      } else if (hasInitializedDb) {
        setGallery([]);
      }

      // 4. Load Testimonials List or Handle Empty State
      if (!testSnap.empty) {
        const customTest: Testimonial[] = [];
        testSnap.forEach((doc) => {
          customTest.push(doc.data() as Testimonial);
        });
        setTestimonials(customTest);
      } else if (hasInitializedDb) {
        setTestimonials([]);
      }

      // 5. Fetch bookings List
      const bookingsSnap = await getDocs(collection(db, "bookings"));
      if (!bookingsSnap.empty) {
        const customBookings: Booking[] = [];
        bookingsSnap.forEach((doc) => {
          customBookings.push(doc.data() as Booking);
        });
        setBookings(customBookings.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      }
    } catch (error) {
      console.warn("Could not retrieve some collections from Firestore. Falling back to magnificent local configurations.", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDatabaseData();
  }, []);

  // Update website document meta header properties dynamically
  useEffect(() => {
    if (settings.seoTitle) {
      document.title = settings.seoTitle;
    }
  }, [settings.seoTitle]);

  // Package Card trigger redirection effect
  const handleSelectPackage = (packageName: string) => {
    setSelectedPackage(packageName);
    const element = document.getElementById("contact");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  const handleBookClick = () => {
    const element = document.getElementById("contact");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0C] flex flex-col items-center justify-center text-stone-300">
        <div className="w-10 h-10 border-2 border-stone-800 border-t-amber-500 rounded-full animate-spin mb-4" />
        <span className="font-serif text-xs uppercase tracking-[0.3em] text-stone-500 animate-pulse">
          Eclat Royal
        </span>
      </div>
    );
  }

  const t = translations[currentLang];

  return (
    <div
      dir={currentLang === "ar" ? "rtl" : "ltr"}
      className="min-h-screen relative selection:bg-amber-500/10 selection:text-amber-400 text-stone-300 antialiased"
      style={{ backgroundColor: settings.darkBgColor || "#0a0a0c" }}
    >
      {/* Decorative background visual texture */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.005)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.005)_1px,transparent_1px)] bg-[size:100px_100px] pointer-events-none" />

      {/* Floating Header */}
      <Header
        logoText={settings.logoText}
        primaryColor={settings.primaryColor}
        isAdminMode={isAdminMode}
        onNavigateToAdmin={() => setIsAdminMode(true)}
        onExitAdmin={() => setIsAdminMode(false)}
        currentLang={currentLang}
        onLanguageChange={handleLanguageChange}
      />

      {isAdminMode ? (
        /* Render Hidden Administrator View Panel */
        <main className="animate-fadeIn">
          <AdminPanel
            settings={settings}
            packages={packages}
            gallery={gallery}
            testimonials={testimonials}
            bookings={bookings}
            onRefreshData={loadDatabaseData}
            primaryColor={settings.primaryColor}
            currentLang={currentLang}
          />
        </main>
      ) : (
        /* Render Client Facing High-Purity Layout landing page */
        <>
          <main className="animate-fadeIn">
            <Hero
              title={settings.heroTitle}
              subtitle={settings.heroSubtitle}
              primaryColor={settings.primaryColor}
              onBookClick={handleBookClick}
              currentLang={currentLang}
            />

            <About
              title={settings.aboutTitle}
              aboutText={settings.aboutText}
              primaryColor={settings.primaryColor}
              currentLang={currentLang}
            />

            <Services primaryColor={settings.primaryColor} currentLang={currentLang} />

            <Packages
              packagesList={packages}
              primaryColor={settings.primaryColor}
              onSelectPackage={handleSelectPackage}
              currentLang={currentLang}
            />

            <Gallery galleryItems={gallery} primaryColor={settings.primaryColor} currentLang={currentLang} />

            <Testimonials
              testimonialsList={testimonials}
              primaryColor={settings.primaryColor}
              currentLang={currentLang}
            />

            <Contact
              selectedPackage={selectedPackage}
              setSelectedPackage={setSelectedPackage}
              contactWhatsApp={settings.contactWhatsApp}
              contactInstagram={settings.contactInstagram}
              primaryColor={settings.primaryColor}
              currentLang={currentLang}
            />
          </main>

          {/* Premium Luxury Footer */}
          <footer className="bg-[#0A0A0A] py-20 px-6 border-t border-white/5 text-center text-stone-500 text-xs font-light">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="text-left">
                <h5 className="font-serif text-white font-semibold tracking-widest text-sm uppercase mb-1">
                  {settings.websiteName}
                </h5>
                <p className="font-mono text-[9px] uppercase tracking-[0.25em] text-stone-500">
                  {t.footer_desc}
                </p>
              </div>

              <div className="flex gap-6 font-mono text-[10px] uppercase tracking-[0.2em] text-stone-400">
                <a href="#about" className="hover:text-white transition-colors uppercase">{t.nav_about}</a>
                <a href="#services" className="hover:text-white transition-colors uppercase">{t.nav_services}</a>
                <a href="#packages" className="hover:text-white transition-colors uppercase">{t.nav_packages}</a>
                <a href="#contact" className="hover:text-white transition-colors uppercase">{t.nav_contact}</a>
              </div>

              <p className="font-mono text-[10px] text-stone-600 tracking-wider">
                © {new Date().getFullYear()} {settings.websiteName}. {t.footer_all_rights}
              </p>
            </div>
          </footer>
        </>
      )}

      {/* Floating Animated WhatsApp action trigger on viewport corner */}
      <FloatingWhatsApp contactWhatsApp={settings.contactWhatsApp} currentLang={currentLang} />
    </div>

  );
}
